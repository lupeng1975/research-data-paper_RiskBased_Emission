# -*- coding: utf-8 -*-
"""
可复现学术溯源系统 —— SCI学术实验平台
python app.py → http://localhost:5001
"""

import os
import json
import random
import time
import hashlib
from datetime import datetime

import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify

from models import Blockchain, MerkleTree, Event, Disposition
from data_adapter import DatasetManager, detect_schema, validate_schema, get_display_name, _read_csv_safe
from model_registry import ModelRegistry, _create_model, _is_available
from experiments import (load_and_split, train_single_model, evaluate_single_model,
                          run_experiment_1_baseline, run_experiment_2_ablation,
                          run_experiment_3_perturbation, run_all_experiments)
from charts import generate_all_charts, cache_charts, load_cached_charts

# ============================================================
# 初始化
# ============================================================

app = Flask(__name__)
BASE_DIR = os.path.dirname(__file__)
DATA_DIR = os.path.join(BASE_DIR, "data")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)

# 全局状态
chain = Blockchain()
events: list = []
dispositions: list = []
recent_scores: list = []

# 管理器
dm = DatasetManager(DATA_DIR, RESULTS_DIR)
registry = ModelRegistry(RESULTS_DIR)

# 缓存
_charts_cache = None
_report_cache = None
_preprocessor_cache = None
_active_model_artifact = None


# ============================================================
# 辅助函数
# ============================================================

def _get_active_pp():
    """获取当前数据集的预处理器（惰性缓存）"""
    global _preprocessor_cache
    if _preprocessor_cache is not None:
        return _preprocessor_cache
    from data_adapter import build_preprocessor
    try:
        meta = dm.get_active_meta()
        schema = meta.get("schema", {})
        df = dm.load_active()
        label_col = schema.get("label_col")
        id_col = schema.get("id_col")
        exclude = schema.get("excluded_cols", [])
        feature_cols = [c for c in df.columns if c != label_col and c != id_col and c not in exclude]
        X = df[feature_cols]
        _preprocessor_cache = build_preprocessor(schema)
        _preprocessor_cache.fit(X)
        return _preprocessor_cache
    except Exception:
        return None


def _get_active_model():
    """获取当前活跃的筛查模型"""
    global _active_model_artifact
    if _active_model_artifact is not None:
        return _active_model_artifact
    artifact = registry.load_artifact(registry.get_active())
    if artifact:
        _active_model_artifact = artifact
    return _active_model_artifact


def _get_threshold():
    """获取当前模型的决策阈值"""
    artifact = _get_active_model()
    if artifact:
        return artifact.get("threshold", 0.4)
    return 0.4


def _ensure_dataset():
    """确保有激活的数据集，否则自动注册并激活默认数据集"""
    meta = dm.get_active_meta()
    if meta and meta.get("schema"):
        return meta

    default_csv = os.path.join(DATA_DIR, "shipment-sensor-dataset.csv")
    if os.path.exists(default_csv):
        dm.register(default_csv, "shipment-sensor-dataset.csv")
        result = dm.activate(dm._load_registry().get(
            [k for k in dm._load_registry()][0], {}).get("dataset_id", ""))
        if result.get("ok"):
            return result["meta"]
    return None


# ============================================================
# 页面
# ============================================================

@app.route("/")
def index():
    return render_template("index.html")


# ============================================================
# API: 健康检查
# ============================================================

@app.route("/api/health")
def health():
    meta = dm.get_active_meta()
    return jsonify({
        "ok": True,
        "active_dataset": meta.get("name", "none") if meta else "none",
        "active_model": registry.get_active(),
        "chain_length": len(chain.chain),
        "events_count": len(events),
        "charts_cached": _charts_cache is not None or bool(load_cached_charts(RESULTS_DIR)),
    })


# ============================================================
# API: 数据源管理
# ============================================================

@app.route("/api/datasets")
def list_datasets():
    return jsonify(dm.list_all())


@app.route("/api/datasets/upload", methods=["POST"])
def upload_dataset():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "未选择文件"})
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"ok": False, "error": "文件名为空"})
    if not file.filename.endswith(".csv"):
        return jsonify({"ok": False, "error": "仅支持CSV格式"})

    filepath = os.path.join(UPLOADS_DIR, file.filename)
    file.save(filepath)

    try:
        meta = dm.register(filepath, file.filename)
        # 返回schema检测结果（用于前端确认映射）
        schema = meta["schema"]
        return jsonify({
            "ok": True,
            "dataset": {
                "dataset_id": meta["dataset_id"],
                "name": meta["name"],
                "schema": schema,
                "hash": meta["hash"][:16] + "...",
            },
            "preview": _preview_csv(filepath),
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


def _preview_csv(filepath: str, rows: int = 5) -> dict:
    """预览CSV前N行"""
    try:
        df = _read_csv_safe(filepath, nrows=rows)
        return {
            "columns": list(df.columns),
            "rows": df.head(rows).to_dict(orient="records"),
            "dtypes": {c: str(df[c].dtype) for c in df.columns},
        }
    except Exception:
        return {"columns": [], "rows": [], "dtypes": {}}


@app.route("/api/datasets/activate", methods=["POST"])
def activate_dataset():
    body = request.get_json() or {}
    dataset_id = body.get("dataset_id", "")
    mapping = body.get("mapping", None)
    if not dataset_id:
        return jsonify({"ok": False, "error": "缺少 dataset_id"})

    global _preprocessor_cache, _active_model_artifact, _charts_cache, _report_cache
    _preprocessor_cache = None
    _active_model_artifact = None
    _charts_cache = None
    _report_cache = None

    result = dm.activate(dataset_id, mapping)
    if result.get("ok"):
        # 使旧模型失效
        new_hash = (result.get("meta") or {}).get("hash", "")
        if new_hash:
            registry.invalidate_by_hash(new_hash)
        # 清除旧实验报告（数据已变，需重新训练）
        for fname in ["E1_baseline.json", "E2_ablation.json",
                      "E3_perturbation.json", "experiment_report.json"]:
            path = os.path.join(RESULTS_DIR, fname)
            if os.path.exists(path):
                os.remove(path)
    return jsonify(result)


@app.route("/api/datasets/active")
def active_dataset_info():
    meta = dm.get_active_meta()
    if not meta:
        return jsonify({"ok": False, "error": "没有激活的数据集"})
    schema = meta.get("schema", {})
    return jsonify({
        "ok": True,
        "name": meta.get("name", ""),
        "hash": (meta.get("hash", "") or "")[:16] + "...",
        "n_rows": schema.get("n_rows", 0),
        "n_cols": schema.get("n_cols", 0),
        "label_col": schema.get("label_col", ""),
        "positive_rate": schema.get("positive_rate", 0),
        "numeric_cols": schema.get("numeric_cols", []),
        "categorical_cols": schema.get("categorical_cols", []),
        "excluded_cols": schema.get("excluded_cols", []),
        "missing_values": schema.get("missing_values", {}),
    })


# ============================================================
# API: 模型管理
# ============================================================

@app.route("/api/models")
def list_models():
    models = registry.list_all()
    # 检查 E1_baseline.json 判断哪些模型已训练
    trained_ids = set()
    e1_path = os.path.join(RESULTS_DIR, "E1_baseline.json")
    if os.path.exists(e1_path):
        try:
            with open(e1_path, "r", encoding="utf-8") as f:
                e1 = json.load(f)
            trained_ids = set(e1.get("results", {}).keys())
        except Exception:
            pass
    for m in models:
        # 以 status 为主(基于实际模型文件), E1报告为辅
        m["trained"] = m.get("status") == "trained" or m["id"] in trained_ids
    return jsonify({"ok": True, "models": models})


@app.route("/api/models/add", methods=["POST"])
def add_model():
    body = request.get_json() or {}
    name = body.get("name", "").strip()
    base_model = body.get("base_model", "").strip()
    custom_params = body.get("params", {})

    if not name:
        return jsonify({"ok": False, "error": "请输入模型名称"})
    if not base_model:
        return jsonify({"ok": False, "error": "请选择基础模型类型"})

    result = registry.add_custom(name, base_model, custom_params)
    return jsonify(result)


@app.route("/api/models/<model_id>/remove", methods=["POST"])
def remove_model(model_id):
    return jsonify(registry.remove(model_id))


@app.route("/api/models/<model_id>/train", methods=["POST"])
def train_model(model_id):
    global _report_cache, _charts_cache
    meta = _ensure_dataset()
    if not meta:
        return jsonify({"ok": False, "error": "没有激活的数据集"})

    m = registry.get(model_id)
    if not m:
        return jsonify({"ok": False, "error": "模型不存在"})
    if not m.get("available"):
        return jsonify({"ok": False, "error": m.get("install_hint", "模型不可用")})

    try:
        X, y, train_idx, val_idx, test_idx, schema = load_and_split(dm)
        X_train, y_train = X.iloc[train_idx], y[train_idx]
        X_val, y_val = X.iloc[val_idx], y[val_idx]
        X_test, y_test = X.iloc[test_idx], y[test_idx]

        from data_adapter import build_preprocessor
        pp = build_preprocessor(schema)
        pp.fit(X_train)

        artifact = train_single_model(model_id, registry, X_train, y_train,
                                       X_val, y_val, pp)
        if isinstance(artifact, dict) and artifact.get("status") == "unavailable":
            return jsonify({"ok": False, "error": "模型不可用"})

        metrics = evaluate_single_model(artifact, X_test, y_test)
        dataset_hash = meta.get("hash", "")
        registry.save_artifact(model_id, artifact, dataset_hash)

        # ── 合并到 E1 报告并重新生成图表 ──
        e1_path = os.path.join(RESULTS_DIR, "E1_baseline.json")
        full_path = os.path.join(RESULTS_DIR, "experiment_report.json")

        # 加载已有 E1 报告（如存在），否则从 _report_cache 取值
        existing = {}
        if os.path.exists(e1_path):
            with open(e1_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        elif _report_cache and "results" in _report_cache:
            existing = _report_cache

        # 合并新模型结果
        clean_metrics = {k: v for k, v in metrics.items() if not k.startswith("_")}
        if "results" in existing:
            existing["results"][model_id] = clean_metrics
        else:
            existing = {
                "experiment": "E1_baseline_comparison",
                "results": {model_id: clean_metrics},
                "timestamp": datetime.now().isoformat(),
            }

        # 持久化
        json_e1 = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")}
                   for k, v in existing["results"].items()}
        with open(e1_path, "w", encoding="utf-8") as f:
            json.dump({**existing, "results": json_e1}, f, ensure_ascii=False, indent=2)

        # 完整报告（含预测值，仅本次训练的模型有 _y_true/_y_prob）
        full_results = {}
        for mid, res in existing["results"].items():
            full_results[mid] = res
        full_results[model_id] = metrics  # 当前模型包含完整预测数据
        full_report = {**existing, "results": full_results}
        with open(full_path, "w", encoding="utf-8") as f:
            json.dump(full_report, f, ensure_ascii=False, indent=2)

        _report_cache = existing

        # 重新生成图表
        df = dm.load_active()
        num_cols = [c for c in schema.get("numeric_cols", []) if c in df.columns]
        X_num = df[num_cols].copy() if num_cols else None
        charts = generate_all_charts(existing, X_num, y)
        cache_charts(charts, RESULTS_DIR)
        _charts_cache = charts

        return jsonify({"ok": True, "model_id": model_id, "metrics": clean_metrics,
                        "models_trained": len(existing["results"])})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/models/train-all", methods=["POST"])
def train_all_models():
    global _report_cache, _charts_cache, _active_model_artifact
    _ensure_dataset()

    try:
        report = run_experiment_1_baseline(dm, registry)
        _report_cache = report
        _charts_cache = None
        _active_model_artifact = None

        # 生成图表
        X, y, _, _, _, schema = load_and_split(dm)
        X_num = None
        if schema.get("numeric_cols"):
            df = dm.load_active()
            num_cols = [c for c in schema["numeric_cols"] if c in df.columns]
            if num_cols:
                X_num = df[num_cols].copy()

        charts = generate_all_charts(report, X_num, y)
        cache_charts(charts, RESULTS_DIR)
        _charts_cache = charts

        summary = {}
        for mid, res in report["results"].items():
            if res.get("status") not in ("error", "unavailable"):
                summary[mid] = {
                    "f1": res.get("f1"), "roc_auc": res.get("roc_auc"),
                    "accuracy": res.get("accuracy"), "pr_auc": res.get("pr_auc"),
                }

        return jsonify({"ok": True, "summary": summary, "charts_available": list(charts.keys())})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/models/train-selected", methods=["POST"])
def train_selected_models():
    global _report_cache, _charts_cache, _active_model_artifact
    _ensure_dataset()

    body = request.get_json() or {}
    model_ids = body.get("model_ids", [])
    if not model_ids or not isinstance(model_ids, list):
        return jsonify({"ok": False, "error": "请提供要训练的模型ID列表 model_ids"})

    # 验证所有模型ID存在且可用
    unavailable = []
    for mid in model_ids:
        m = registry.get(mid)
        if not m:
            return jsonify({"ok": False, "error": f"模型不存在: {mid}"})
        if not m.get("available"):
            unavailable.append(mid)
    if unavailable:
        return jsonify({"ok": False, "error": f"以下模型不可用: {', '.join(unavailable)}"})

    try:
        X, y, train_idx, val_idx, test_idx, schema = load_and_split(dm)
        X_train, y_train = X.iloc[train_idx], y[train_idx]
        X_val, y_val = X.iloc[val_idx], y[val_idx]
        X_test, y_test = X.iloc[test_idx], y[test_idx]

        from data_adapter import build_preprocessor

        trained = {}
        failed = {}
        n_total = len(model_ids)

        for i, mid in enumerate(model_ids):
            name_cn = registry.get(mid).get("name_cn", mid)
            print(f"  [{i+1}/{n_total}] 训练 {mid} ({name_cn})...", flush=True)
            try:
                pp = build_preprocessor(schema)
                pp.fit(X_train)

                artifact = train_single_model(mid, registry, X_train, y_train,
                                               X_val, y_val, pp)
                if isinstance(artifact, dict) and artifact.get("status") == "unavailable":
                    failed[mid] = artifact.get("error", "模型不可用")
                    continue

                metrics = evaluate_single_model(artifact, X_test, y_test)
                dataset_hash = dm.get_active_meta().get("hash", "")
                registry.save_artifact(mid, artifact, dataset_hash)
                trained[mid] = {k: v for k, v in metrics.items() if not k.startswith("_")}
            except Exception as e:
                failed[mid] = str(e)

        # ── 合并到 E1 报告 ──
        e1_path = os.path.join(RESULTS_DIR, "E1_baseline.json")
        full_path = os.path.join(RESULTS_DIR, "experiment_report.json")

        existing = {}
        if os.path.exists(e1_path):
            with open(e1_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        elif _report_cache and "results" in _report_cache:
            existing = _report_cache

        if "results" in existing:
            for mid, m in trained.items():
                existing["results"][mid] = m
        else:
            existing = {
                "experiment": "E1_baseline_comparison",
                "results": trained,
                "timestamp": datetime.now().isoformat(),
            }

        json_e1 = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")}
                   for k, v in existing["results"].items()}
        with open(e1_path, "w", encoding="utf-8") as f:
            json.dump({**existing, "results": json_e1}, f, ensure_ascii=False, indent=2)

        full_results = dict(existing["results"])
        for mid, m in trained.items():
            full_results[mid] = m
        full_report = {**existing, "results": full_results}
        with open(full_path, "w", encoding="utf-8") as f:
            json.dump(full_report, f, ensure_ascii=False, indent=2)

        _report_cache = existing
        _active_model_artifact = None

        # ── 重新生成图表 ──
        df = dm.load_active()
        num_cols = [c for c in schema.get("numeric_cols", []) if c in df.columns]
        X_num = df[num_cols].copy() if num_cols else None
        charts = generate_all_charts(existing, X_num, y)
        cache_charts(charts, RESULTS_DIR)
        _charts_cache = charts

        return jsonify({
            "ok": True,
            "trained": trained,
            "failed": failed,
            "models_trained": len(trained),
            "total": n_total,
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/models/active", methods=["POST"])
def set_active_model():
    body = request.get_json() or {}
    model_id = body.get("model_id", "")
    global _active_model_artifact
    _active_model_artifact = None
    return jsonify(registry.set_active(model_id))


# ============================================================
# API: 实验数据
# ============================================================

@app.route("/api/experiments")
def get_experiments():
    global _report_cache

    e1_path = os.path.join(RESULTS_DIR, "E1_baseline.json")
    e2_path = os.path.join(RESULTS_DIR, "E2_ablation.json")
    e3_path = os.path.join(RESULTS_DIR, "E3_perturbation.json")

    e1 = None
    e2 = None
    e3 = None

    if os.path.exists(e1_path):
        with open(e1_path, "r", encoding="utf-8") as f:
            e1 = json.load(f)
    if os.path.exists(e2_path):
        with open(e2_path, "r", encoding="utf-8") as f:
            e2 = json.load(f)
    if os.path.exists(e3_path):
        with open(e3_path, "r", encoding="utf-8") as f:
            e3 = json.load(f)

    # 数据集元数据
    meta = dm.get_active_meta()
    schema = meta.get("schema", {}) if meta else {}
    ds_hash = (meta.get("hash", "") or "") if meta else ""

    # 获取完整报告（含预测值）用于图表
    full_report_path = os.path.join(RESULTS_DIR, "experiment_report.json")
    if os.path.exists(full_report_path) and not _report_cache:
        with open(full_report_path, "r", encoding="utf-8") as f:
            _report_cache = json.load(f)

    return jsonify({
        "ok": True,
        "E1": e1,
        "E2": e2,
        "E3": e3,
        "full_report": _report_cache,
        "dataset_audit": {
            "total_rows": schema.get("n_rows", 0),
            "positive_rate": schema.get("positive_rate", 0),
            "operational_features": len(schema.get("numeric_cols", [])) + len(schema.get("categorical_cols", [])),
            "numeric_features": len(schema.get("numeric_cols", [])),
            "categorical_features": len(schema.get("categorical_cols", [])),
        },
        "dataset_hash": ds_hash[:32] if ds_hash else "",
        "seed": 20260729,
    })


@app.route("/api/experiments/run", methods=["POST"])
def run_experiments():
    global _report_cache, _charts_cache
    body = request.get_json() or {}
    which = body.get("which", "E1")

    _ensure_dataset()

    try:
        if which == "E1":
            report = run_experiment_1_baseline(dm, registry)
            _report_cache = report
        elif which == "E2":
            report = run_experiment_2_ablation(dm, registry)
        elif which == "E3":
            report = run_experiment_3_perturbation(dm, registry)
        elif which == "all":
            run_all_experiments(dm, registry)
            report = _report_cache
        else:
            return jsonify({"ok": False, "error": f"未知实验: {which}"})

        # 生成图表
        try:
            X, y, _, _, _, schema = load_and_split(dm)
            X_num = None
            if schema.get("numeric_cols"):
                df = dm.load_active()
                num_cols = [c for c in schema["numeric_cols"] if c in df.columns]
                if num_cols:
                    X_num = df[num_cols].copy()

            full_report = _report_cache if _report_cache else report
            charts = generate_all_charts(full_report, X_num, y)
            cache_charts(charts, RESULTS_DIR)
            _charts_cache = charts
        except Exception as e:
            print(f"Chart generation warning: {e}")

        return jsonify({"ok": True, "experiment": which})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


# ============================================================
# API: 图表
# ============================================================

@app.route("/api/charts")
def get_charts():
    global _charts_cache
    model_ids_str = request.args.get("model_ids", "")
    if model_ids_str:
        # 过滤：只生成指定模型的图表
        model_ids = set(mid.strip() for mid in model_ids_str.split(",") if mid.strip())
        full_path = os.path.join(RESULTS_DIR, "experiment_report.json")
        report = None
        if os.path.exists(full_path):
            with open(full_path, "r", encoding="utf-8") as f:
                report = json.load(f)
        elif _report_cache:
            report = _report_cache
        if report and model_ids:
            filtered_results = {mid: res for mid, res in report.get("results", {}).items()
                                if mid in model_ids}
            filtered_report = {**report, "results": filtered_results}
            # 获取数值特征用于梯度下降图表
            try:
                X, y, _, _, _, schema = load_and_split(dm)
                X_num = None
                if schema.get("numeric_cols"):
                    df = dm.load_active()
                    num_cols = [c for c in schema["numeric_cols"] if c in df.columns]
                    if num_cols:
                        X_num = df[num_cols].copy()
            except Exception:
                X_num, y = None, None
            charts = generate_all_charts(filtered_report, X_num, y)
            return jsonify({"ok": True, "charts": charts, "model_ids": sorted(model_ids)})
    if _charts_cache is None:
        _charts_cache = load_cached_charts(RESULTS_DIR)
    return jsonify({"ok": True, "charts": _charts_cache or {}})


@app.route("/api/charts/<chart_id>")
def get_chart(chart_id):
    charts = load_cached_charts(RESULTS_DIR)
    if chart_id in charts:
        return jsonify({"ok": True, "spec": charts[chart_id]})
    return jsonify({"ok": False, "error": f"图表 {chart_id} 不存在"})


@app.route("/api/charts/refresh", methods=["POST"])
def refresh_charts():
    global _charts_cache
    report_path = os.path.join(RESULTS_DIR, "experiment_report.json")
    if os.path.exists(report_path):
        with open(report_path, "r", encoding="utf-8") as f:
            report = json.load(f)

        X, y, _, _, _, schema = load_and_split(dm)
        X_num = None
        if schema.get("numeric_cols"):
            df = dm.load_active()
            num_cols = [c for c in schema["numeric_cols"] if c in df.columns]
            if num_cols:
                X_num = df[num_cols].copy()

        charts = generate_all_charts(report, X_num, y)
        cache_charts(charts, RESULTS_DIR)
        _charts_cache = charts
        return jsonify({"ok": True, "charts": list(charts.keys())})

    return jsonify({"ok": False, "error": "无实验报告，请先运行实验"})


# ============================================================
# API: 数据采集
# ============================================================

@app.route("/api/collect", methods=["POST"])
def collect():
    body = request.get_json() or {}
    _ensure_dataset()

    meta = dm.get_active_meta()
    schema = meta.get("schema", {})

    try:
        df = dm.load_active()
        row = df.sample(1).iloc[0]
        sample_id = str(row.get(schema.get("id_col", df.columns[0]),
                                f"SAMPLE-{random.randint(1, 9999):05d}"))

        # 提取所有特征
        label_col = schema.get("label_col")
        id_col = schema.get("id_col")
        exclude = schema.get("excluded_cols", [])
        feature_cols = [c for c in df.columns if c != label_col and c != id_col and c not in exclude]

        features = {}
        for f in feature_cols:
            val = row.get(f)
            if pd.isna(val):
                features[f] = None
            elif isinstance(val, (np.integer,)):
                features[f] = int(val)
            elif isinstance(val, (np.floating,)):
                features[f] = float(val)
            else:
                features[f] = str(val)

        true_label = int(row[label_col]) if label_col else 0
    except Exception as e:
        sample_id = f"DEMO-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        features = {"temp": round(random.uniform(2, 8), 2),
                    "humidity": round(random.uniform(40, 80), 1)}
        true_label = 0

    device_id = body.get("device_id", f"GW-{random.choice(['SZ','GZ','HK'])}-{random.randint(1,99):03d}")
    event = Event(sample_id, "acquire", features, device_id=device_id,
                  operator=body.get("operator", "操作员_01"))
    event.gateway_verified = True
    event.seq_no = len(events) + 1
    event._true_label = true_label
    events.append(event)

    block = chain.add_block({
        "event_id": event.event_id, "type": "acquire",
        "shipment_id": sample_id, "payload_hash": event.payload_hash,
        "device_id": device_id, "gateway_verified": True,
    })

    return jsonify({
        "ok": True,
        "event": event.to_dict(),
        "true_label": true_label,
        "block_index": block.index,
        "block_hash": block.hash[:16] + "...",
        "chain_length": len(chain.chain),
    })


# ============================================================
# API: 智能筛查
# ============================================================

@app.route("/api/screen", methods=["POST"])
def screen():
    body = request.get_json() or {}
    _ensure_dataset()

    # 获取最新事件或请求中的事件
    if events:
        last = events[-1]
        features = last.payload
        sample_id = last.shipment_id
        true_label = getattr(last, "_true_label", 0)
    else:
        features = {}
        sample_id = "DEMO"
        true_label = 0

    model_id = body.get("model_id", registry.get_active())
    artifact = registry.load_artifact(model_id)

    if artifact:
        pipe = artifact["pipeline"]
        threshold = artifact.get("threshold", 0.4)
        model_name = registry.get(model_id).get("name", model_id) if registry.get(model_id) else model_id
        try:
            df = pd.DataFrame([features])
            for c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="ignore")
            score = float(pipe.predict_proba(df)[0, 1])
        except Exception:
            score = round(random.uniform(0.1, 0.9), 4)
            model_name = f"{model_name} (fallback)"
    else:
        score = round(random.uniform(0.1, 0.9), 4)
        threshold = 0.4
        model_name = "fallback (random)"

    alerted = score >= threshold
    recent_scores.append(score)

    block = chain.add_block({
        "type": "screen", "shipment_id": sample_id,
        "score": round(score, 4), "threshold": threshold,
        "alerted": alerted, "model": model_name,
    })

    # 获取模型指标
    metrics_display = {}
    m_info = registry.get(model_id)
    if m_info and m_info.get("metrics"):
        m = m_info["metrics"]
        metrics_display = {
            "roc_auc": m.get("roc_auc", 0),
            "roc_auc_ci": f"{m.get('roc_auc_ci', [0,0])[0]:.3f}-{m.get('roc_auc_ci', [0,0])[1]:.3f}",
            "pr_auc": m.get("pr_auc", 0),
            "f1": m.get("f1", 0),
            "f1_ci": f"{m.get('f1_ci', [0,0])[0]:.3f}-{m.get('f1_ci', [0,0])[1]:.3f}",
            "precision": m.get("precision", 0),
            "recall": m.get("recall", 0),
            "accuracy": m.get("accuracy", 0),
            "dataset": f"{dm.get_active_meta().get('schema', {}).get('n_rows', '?')}条 · "
                       f"{len(dm.get_active_meta().get('schema', {}).get('numeric_cols', []))}数值特征 · "
                       f"{dm.get_active_meta().get('schema', {}).get('positive_rate', 0):.1%}阳性",
        }
        metrics_display["confusion_matrix"] = m.get("confusion_matrix", {"tp":0,"fn":0,"fp":0,"tn":0})

    return jsonify({
        "ok": True,
        "shipment_id": sample_id,
        "score": round(score, 4),
        "threshold": threshold,
        "alerted": alerted,
        "decision": "⚠️ 需人工审查" if alerted else "✅ 正常",
        "true_label": true_label,
        "model": model_name,
        "block_index": block.index,
        "metrics": metrics_display,
    })


# ============================================================
# API: 区块链 / Merkle / 处置 / 统计
# ============================================================

@app.route("/api/chain")
def get_chain():
    return jsonify({
        "ok": True,
        "chain_length": len(chain.chain),
        "verified": chain.verify(),
        "blocks": chain.to_list()[-5:],
    })


@app.route("/api/chain/verify", methods=["POST"])
def verify_chain():
    detail = chain.verify_detail()
    return jsonify({"ok": True, **detail})


@app.route("/api/merkle")
def get_merkle():
    payloads = [e.payload_hash for e in events[-8:]] if events else [f"payload_{i}" for i in range(4)]
    tree = MerkleTree(payloads)
    return jsonify({"ok": True, "merkle": tree.to_dict()})


@app.route("/api/disposition", methods=["POST"])
def do_disposition():
    body = request.get_json() or {}
    event_id = body.get("event_id", events[-1].event_id if events else "DEMO-001")
    decision = body.get("decision", "review")
    reviewer = body.get("reviewer", "质量员_01")
    reason = body.get("reason", "人工审查")

    disp = Disposition(event_id, decision, reviewer, reason)
    dispositions.append(disp)

    block = chain.add_block({
        "type": "disposition", "event_id": event_id,
        "decision": decision, "reviewer": reviewer, "reason": reason,
    })

    return jsonify({
        "ok": True,
        "disposition": disp.to_dict(),
        "block_index": block.index,
    })


@app.route("/api/dispositions")
def get_dispositions():
    return jsonify({"ok": True, "dispositions": [d.to_dict() for d in dispositions]})


@app.route("/api/stats")
def get_stats():
    return jsonify({
        "ok": True,
        "total_events": len(events),
        "total_dispositions": len(dispositions),
        "chain_length": len(chain.chain),
        "chain_verified": chain.verify(),
        "recent_scores_count": len(recent_scores),
        "active_dataset": dm.get_active_meta().get("name", "none") if dm.get_active_meta() else "none",
        "active_model": registry.get_active(),
        "disposition_summary": {
            "release": sum(1 for d in dispositions if d.decision == "release"),
            "quarantine": sum(1 for d in dispositions if d.decision == "quarantine"),
            "reject": sum(1 for d in dispositions if d.decision == "reject"),
            "review": sum(1 for d in dispositions if d.decision == "review"),
        },
    })


# ============================================================
# API: 一键演示
# ============================================================

@app.route("/api/demo/full-flow", methods=["POST"])
def demo_full_flow():
    global _active_model_artifact
    meta = _ensure_dataset()
    if not meta:
        return jsonify({"ok": False, "error": "没有激活的数据集"})

    schema = meta.get("schema", {})
    df = dm.load_active()
    row = df.sample(1).iloc[0]
    label_col = schema.get("label_col")
    id_col = schema.get("id_col")
    exclude = schema.get("excluded_cols", [])
    feature_cols = [c for c in df.columns if c != label_col and c != id_col and c not in exclude]

    sample_id = str(row.get(id_col, f"DEMO-{random.randint(1, 9999)}"))
    true_label = int(row[label_col]) if label_col else 0

    # 构建payload
    payload = {}
    for f in feature_cols:
        val = row.get(f)
        if pd.isna(val):
            payload[f] = None
        elif isinstance(val, (np.integer,)):
            payload[f] = int(val)
        elif isinstance(val, (np.floating,)):
            payload[f] = round(float(val), 4)
        else:
            payload[f] = str(val)

    steps = []
    t_total = time.time()

    # Step 1: 采集
    t1 = time.time()
    event = Event(sample_id, "acquire", payload, device_id=f"GW-SZ-{random.randint(1,50):03d}")
    event.gateway_verified = True
    event._true_label = true_label
    events.append(event)
    b1 = chain.add_block({"type": "acquire", "event_id": event.event_id,
                           "shipment_id": sample_id, "payload_hash": event.payload_hash})
    steps.append({"step": 1, "name": "📡 数据采集 (来自真实数据集)",
                  "duration_ms": round((time.time() - t1) * 1000),
                  "detail": f"事件:{event.event_id} | {len(payload)}个特征 | 标签:{true_label}"})

    # Step 2: 验证+承诺
    t2 = time.time()
    b2 = chain.add_block({"type": "commit", "event_id": event.event_id,
                           "payload_hash": event.payload_hash})
    tree = MerkleTree([e.payload_hash for e in events[-4:]] if len(events) >= 4
                      else [event.payload_hash] + [hashlib.sha256(f"d{i}".encode()).hexdigest() for i in range(1, 4)])
    steps.append({"step": 2, "name": "🔗 边缘验证 + Merkle承诺",
                  "duration_ms": round((time.time() - t2) * 1000),
                  "detail": f"Merkle根: {tree.root()[:16]}... | 链长: {len(chain.chain)}"})

    # Step 3: 筛查
    t3 = time.time()
    artifact = _get_active_model()
    model_name = registry.get_active()
    threshold = 0.4
    score = 0.5
    alerted = False
    if artifact:
        threshold = artifact.get("threshold", 0.4)
        try:
            df_row = pd.DataFrame([payload])
            for c in df_row.columns:
                df_row[c] = pd.to_numeric(df_row[c], errors="ignore")
            score = float(artifact["pipeline"].predict_proba(df_row)[0, 1])
        except Exception:
            score = random.uniform(0.1, 0.9)
    alerted = score >= threshold
    recent_scores.append(score)
    model_label = registry.get(model_name)
    model_label = model_label.get("name", model_name) if model_label else model_name
    b3 = chain.add_block({"type": "screen", "shipment_id": sample_id,
                           "score": round(score, 4), "threshold": threshold, "alerted": alerted})
    steps.append({"step": 3, "name": f"🧠 {model_label} 筛查",
                  "duration_ms": round((time.time() - t3) * 1000),
                  "detail": f"评分:{score:.4f} | 阈值:{threshold} | {'⚠️异常' if alerted else '✅正常'}"})

    # Step 4: 处置
    t4 = time.time()
    decision = "release" if not alerted else random.choice(["quarantine", "review"])
    reason = "筛查正常,准予放行" if decision == "release" else "筛查异常,需审查"
    disp = Disposition(event.event_id, decision, "质量员_01", reason)
    dispositions.append(disp)
    b4 = chain.add_block({"type": "disposition", "event_id": event.event_id,
                           "decision": decision, "reviewer": "质量员_01", "reason": reason})
    steps.append({"step": 4, "name": "👤 人工处置",
                  "duration_ms": round((time.time() - t4) * 1000),
                  "detail": f"决策:{disp.to_dict()['decision_cn']} | 审查人:质量员_01"})

    total_ms = round((time.time() - t_total) * 1000)

    # RF指标
    rf_info = _get_active_model()
    rf_metrics = None
    if rf_info:
        rf_metrics = {
            "roc_auc": rf_info.get("metrics", {}).get("roc_auc", 0),
            "roc_auc_ci": rf_info.get("metrics", {}).get("roc_auc_ci", [0, 0]),
            "f1": rf_info.get("metrics", {}).get("f1", 0),
            "f1_ci": rf_info.get("metrics", {}).get("f1_ci", [0, 0]),
            "precision": rf_info.get("metrics", {}).get("precision", 0),
            "recall": rf_info.get("metrics", {}).get("recall", 0),
            "confusion_matrix": rf_info.get("metrics", {}).get("confusion_matrix",
                                                                {"tp": 0, "fn": 0, "fp": 0, "tn": 0}),
        }

    return jsonify({
        "ok": True, "shipment_id": sample_id, "total_duration_ms": total_ms,
        "chain_length": len(chain.chain), "chain_verified": chain.verify(),
        "steps": steps,
        "rf_performance": rf_metrics,
        "charts_available": bool(load_cached_charts(RESULTS_DIR)),
    })


# ============================================================
# 启动
# ============================================================

if __name__ == "__main__":
    _ensure_dataset()

    print("\n" + "=" * 60)
    print("  可复现学术溯源系统 —— SCI学术实验平台")
    print("  Seed: 20260729 | 多模型对比 | 学术图表 | 区块链存证")
    print("  http://localhost:5001")
    print("=" * 60 + "\n")

    meta = dm.get_active_meta()
    if meta:
        schema = meta.get("schema", {})
        print(f"  数据集: {meta.get('name')}")
        print(f"  样本数: {schema.get('n_rows')} | 特征: {len(schema.get('numeric_cols', [])) + len(schema.get('categorical_cols', []))}")
        print(f"  阳性率: {schema.get('positive_rate', 0):.1%} | 标签: {schema.get('label_col')}")
        print(f"  内置模型: {sum(1 for m in registry.list_all() if m.get('builtin') and m.get('available'))}")
        print()

    app.run(debug=True, host="0.0.0.0", port=5001)
