# -*- coding: utf-8 -*-
"""
区块链仿真 + 数据模型 —— 纯Python实现，无需Hyperledger Fabric
可复现学术溯源系统 · Seed 20260729
"""

import hashlib
import json
from datetime import datetime
from typing import Optional

# ============================================================
# SHA-256 哈希链（模拟 Fabric 账本）
# ============================================================

def sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


class Block:
    """区块"""
    def __init__(self, index: int, data: dict, prev_hash: str):
        self.index = index
        self.timestamp = datetime.now()
        self.data = data
        self.prev_hash = prev_hash
        self.nonce = 0
        self.hash = self._mine()

    def _mine(self):
        raw = f"{self.index}{self.timestamp.isoformat()}{json.dumps(self.data, ensure_ascii=False, default=str)}{self.prev_hash}{self.nonce}"
        return sha256(raw)

    def to_dict(self):
        return {
            "index": self.index,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "data": self.data,
            "prev_hash": self.prev_hash[:12] + "...",
            "hash": self.hash[:12] + "...",
            "hash_full": self.hash,
            "nonce": self.nonce,
        }


class Blockchain:
    """仿真联盟链"""
    def __init__(self):
        genesis = Block(0, {"type": "GENESIS", "desc": "学术溯源联盟链创世区块"}, "0" * 64)
        self.chain = [genesis]

    def add_block(self, data: dict) -> Block:
        prev = self.chain[-1]
        block = Block(len(self.chain), data, prev.hash)
        self.chain.append(block)
        return block

    def verify(self) -> bool:
        for i in range(1, len(self.chain)):
            curr, prev = self.chain[i], self.chain[i - 1]
            if curr.prev_hash != prev.hash:
                return False
            if curr.hash != curr._mine():
                return False
        return True

    def verify_detail(self) -> dict:
        """详细验证，返回第一个断裂位置"""
        for i in range(1, len(self.chain)):
            curr, prev = self.chain[i], self.chain[i - 1]
            if curr.prev_hash != prev.hash:
                return {"valid": False, "broken_at": i, "reason": "prev_hash mismatch"}
            if curr.hash != curr._mine():
                return {"valid": False, "broken_at": i, "reason": "hash recalculation mismatch"}
        return {"valid": True, "broken_at": None, "reason": None}

    def to_list(self):
        return [b.to_dict() for b in self.chain]


# ============================================================
# Merkle 树
# ============================================================

class MerkleTree:
    def __init__(self, items: list[str]):
        self.leaves = [sha256(item) for item in items] if items else ["0" * 64]
        self.levels = [self.leaves]
        self._build()

    def _build(self):
        current = self.leaves
        while len(current) > 1:
            if len(current) % 2 == 1:
                current.append(current[-1])
            next_level = [sha256(current[i] + current[i + 1]) for i in range(0, len(current), 2)]
            self.levels.append(next_level)
            current = next_level

    def root(self) -> str:
        return self.levels[-1][0] if self.levels else sha256("")

    def to_dict(self):
        result = []
        for level in self.levels:
            result.append([h[:16] + "…" for h in level])
        return {"levels": result, "root": self.root()[:24] + "…"}


# ============================================================
# 事件模型
# ============================================================

EVENT_TYPES = {
    "acquire": "📡 数据采集",
    "gateway": "🔐 网关验证",
    "commit": "🔗 哈希承诺",
    "endorse": "✍️ 背书提交",
    "screen": "🧠 智能筛查",
    "disposition": "👤 人工处置",
}

class Event:
    _counter = 1

    def __init__(self, shipment_id: str, event_type: str, payload: dict,
                 device_id: str = "", operator: str = ""):
        self.event_id = f"EVT-{datetime.now().strftime('%Y%m%d')}-{Event._counter:04d}"
        Event._counter += 1
        self.shipment_id = shipment_id
        self.event_type = event_type
        self.payload = payload
        self.payload_hash = sha256(json.dumps(payload, ensure_ascii=False, default=str))
        self.device_id = device_id
        self.operator = operator
        self.timestamp = datetime.now()
        self.gateway_verified = False
        self.seq_no = 0

    def to_dict(self):
        return {
            "event_id": self.event_id,
            "shipment_id": self.shipment_id,
            "event_type": self.event_type,
            "event_type_cn": EVENT_TYPES.get(self.event_type, self.event_type),
            "payload": self.payload,
            "payload_hash": self.payload_hash[:16] + "...",
            "device_id": self.device_id,
            "operator": self.operator,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "gateway_verified": self.gateway_verified,
            "seq_no": self.seq_no,
        }


# ============================================================
# 处置记录
# ============================================================

DISPOSITION_DECISIONS = {"release": "✅ 放行", "quarantine": "⚠️ 隔离",
                          "reject": "🚫 拒收", "review": "🔍 复查"}

class Disposition:
    def __init__(self, event_id: str, decision: str, reviewer: str, reason: str):
        self.event_id = event_id
        self.decision = decision
        self.reviewer = reviewer
        self.reason = reason
        self.timestamp = datetime.now()

    def to_dict(self):
        return {
            "event_id": self.event_id,
            "decision": self.decision,
            "decision_cn": DISPOSITION_DECISIONS.get(self.decision, self.decision),
            "reviewer": self.reviewer,
            "reason": self.reason,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        }
