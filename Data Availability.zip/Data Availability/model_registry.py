# -*- coding: utf-8 -*-
"""
模型注册表 —— 管理内置+用户自定义ML模型
可复现学术溯源系统 · Seed 20260729
"""

import os
import json
import pickle
import hashlib
from datetime import datetime
from copy import deepcopy

import numpy as np
import pandas as pd
from sklearn.ensemble import (RandomForestClassifier, ExtraTreesClassifier,
                               GradientBoostingClassifier)
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC

SEED = 20260729

# ============================================================
# 可选依赖（优雅降级）
# ============================================================

XGB_AVAILABLE = False
LGB_AVAILABLE = False
TORCH_AVAILABLE = False
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except ImportError:
    XGBClassifier = None

try:
    from lightgbm import LGBMClassifier
    LGB_AVAILABLE = True
except ImportError:
    LGBMClassifier = None

try:
    from temporal_model import LSTMClassifier, TORCH_AVAILABLE as _TORCH_OK
    TORCH_AVAILABLE = _TORCH_OK
except ImportError:
    LSTMClassifier = None


# ============================================================
# 模型工厂定义
# ============================================================

BUILTIN_MODELS = {
    "random_forest": {
        "name": "Random Forest (RF-500)",
        "name_cn": "随机森林 (RF-500)",
        "description": "500 trees, min_samples_leaf=2, 论文基线模型",
        "params": {"n_estimators": 500, "min_samples_leaf": 2, "random_state": SEED, "n_jobs": -1},
        "param_schema": {
            "n_estimators": {"type": "int", "default": 500, "min": 50, "max": 2000},
            "min_samples_leaf": {"type": "int", "default": 2, "min": 1, "max": 100},
            "max_depth": {"type": "int", "default": None, "min": 2, "max": 100},
        },
    },
    "extra_trees": {
        "name": "Extra Trees (ET-500)",
        "name_cn": "极端随机树 (ET-500)",
        "description": "500 trees, 更高随机性的集成方法",
        "params": {"n_estimators": 500, "min_samples_leaf": 2, "random_state": SEED, "n_jobs": -1},
        "param_schema": {
            "n_estimators": {"type": "int", "default": 500, "min": 50, "max": 2000},
            "min_samples_leaf": {"type": "int", "default": 2, "min": 1, "max": 100},
        },
    },
    "gradient_boosting": {
        "name": "Gradient Boosting (GBDT)",
        "name_cn": "梯度提升树 (GBDT)",
        "description": "200 trees, learning_rate=0.05, 经典提升方法",
        "params": {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 5, "random_state": SEED},
        "param_schema": {
            "n_estimators": {"type": "int", "default": 200, "min": 50, "max": 2000},
            "learning_rate": {"type": "float", "default": 0.05, "min": 0.001, "max": 1.0},
            "max_depth": {"type": "int", "default": 5, "min": 2, "max": 20},
        },
    },
    "logistic_regression": {
        "name": "Logistic Regression",
        "name_cn": "逻辑回归 (LR)",
        "description": "class_weight=balanced, L2正则化",
        "params": {"class_weight": "balanced", "max_iter": 2000, "C": 1.0, "random_state": SEED},
        "param_schema": {
            "C": {"type": "float", "default": 1.0, "min": 0.01, "max": 100.0},
        },
    },
    "mlp": {
        "name": "MLP Neural Network",
        "name_cn": "多层感知机 (MLP)",
        "description": "hidden=(64,32), early_stopping, 记录训练损失曲线",
        "params": {"hidden_layer_sizes": (64, 32), "early_stopping": True,
                   "max_iter": 1000, "random_state": SEED, "alpha": 0.001},
        "param_schema": {
            "hidden_layer_sizes": {"type": "str", "default": "64,32", "description": "逗号分隔, 如 128,64,32"},
            "alpha": {"type": "float", "default": 0.001, "min": 0.00001, "max": 1.0},
        },
        "tracks_loss": True,  # 标记该模型支持损失曲线
    },
    "svm": {
        "name": "Support Vector Machine",
        "name_cn": "支持向量机 (SVM)",
        "description": "RBF核, probability=True, class_weight=balanced",
        "params": {"kernel": "rbf", "class_weight": "balanced",
                   "C": 1.0, "gamma": "scale", "max_iter": 5000,
                   "cache_size": 2000, "random_state": SEED},
        "param_schema": {
            "C": {"type": "float", "default": 1.0, "min": 0.01, "max": 100.0},
        },
    },
    "xgboost": {
        "name": "XGBoost",
        "name_cn": "XGBoost",
        "description": "n_estimators=200, learning_rate=0.05" if XGB_AVAILABLE else "需要安装 xgboost 包",
        "params": {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 5,
                   "random_state": SEED, "use_label_encoder": False, "eval_metric": "logloss"},
        "param_schema": {
            "n_estimators": {"type": "int", "default": 200, "min": 50, "max": 2000},
            "learning_rate": {"type": "float", "default": 0.05, "min": 0.001, "max": 1.0},
        },
    },
    "lightgbm": {
        "name": "LightGBM",
        "name_cn": "LightGBM",
        "description": "n_estimators=200, learning_rate=0.05" if LGB_AVAILABLE else "需要安装 lightgbm 包",
        "params": {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 5,
                   "random_state": SEED, "verbose": -1},
        "param_schema": {
            "n_estimators": {"type": "int", "default": 200, "min": 50, "max": 2000},
            "learning_rate": {"type": "float", "default": 0.05, "min": 0.001, "max": 1.0},
        },
    },
    "lstm": {
        "name": "Temporal LSTM",
        "name_cn": "时序验证 LSTM",
        "description": "LSTM 时序分类器, 滑动窗口+零填充, 内部早停, 记录损失曲线" if TORCH_AVAILABLE else "需要安装 pytorch 包",
        "params": {"seq_len": 12, "hidden_dim": 64, "num_layers": 2, "dropout": 0.2,
                   "lr": 0.001, "epochs": 100, "batch_size": 256,
                   "patience": 10, "validation_fraction": 0.15,
                   "random_state": SEED},
        "param_schema": {
            "seq_len": {"type": "int", "default": 12, "min": 2, "max": 64},
            "hidden_dim": {"type": "int", "default": 64, "min": 16, "max": 256},
            "num_layers": {"type": "int", "default": 2, "min": 1, "max": 4},
            "dropout": {"type": "float", "default": 0.2, "min": 0.0, "max": 0.9},
            "lr": {"type": "float", "default": 0.001, "min": 0.0001, "max": 0.1},
            "epochs": {"type": "int", "default": 100, "min": 10, "max": 500},
            "batch_size": {"type": "int", "default": 256, "min": 32, "max": 2048},
        },
        "tracks_loss": True,
    },
}

# 不可用模型的提示
UNAVAILABLE_MSG = {
    "xgboost": "XGBoost 未安装。运行: pip install xgboost",
    "lightgbm": "LightGBM 未安装。运行: pip install lightgbm",
    "lstm": "PyTorch 未安装。运行: pip install torch",
}


def _create_model(model_id: str, params: dict = None):
    """根据model_id创建模型实例"""
    if model_id not in BUILTIN_MODELS:
        raise ValueError(f"未知模型: {model_id}")

    config = BUILTIN_MODELS[model_id]
    model_params = deepcopy(config["params"])
    if params:
        model_params.update(params)

    if model_id == "random_forest":
        return RandomForestClassifier(**model_params)
    elif model_id == "extra_trees":
        return ExtraTreesClassifier(**model_params)
    elif model_id == "gradient_boosting":
        return GradientBoostingClassifier(**model_params)
    elif model_id == "logistic_regression":
        return LogisticRegression(**model_params)
    elif model_id == "mlp":
        hs = model_params.get("hidden_layer_sizes", (64, 32))
        if isinstance(hs, str):
            hs = tuple(int(x.strip()) for x in hs.split(","))
            model_params["hidden_layer_sizes"] = hs
        return MLPClassifier(**model_params)
    elif model_id == "svm":
        from sklearn.calibration import CalibratedClassifierCV
        svc = SVC(**model_params)
        return CalibratedClassifierCV(svc, ensemble=False)
    elif model_id == "xgboost":
        if not XGB_AVAILABLE:
            raise ImportError("XGBoost 未安装")
        return XGBClassifier(**model_params)
    elif model_id == "lightgbm":
        if not LGB_AVAILABLE:
            raise ImportError("LightGBM 未安装")
        return LGBMClassifier(**model_params)
    elif model_id == "lstm":
        if not TORCH_AVAILABLE:
            raise ImportError("PyTorch 未安装")
        return LSTMClassifier(**model_params)
    else:
        raise ValueError(f"未知模型类型: {model_id}")


def _is_available(model_id: str) -> bool:
    """检查模型是否可用"""
    if model_id == "xgboost":
        return XGB_AVAILABLE
    if model_id == "lightgbm":
        return LGB_AVAILABLE
    if model_id == "lstm":
        return TORCH_AVAILABLE
    return True


def _tracks_loss(model_id: str) -> bool:
    """检查模型是否追踪损失"""
    return BUILTIN_MODELS.get(model_id, {}).get("tracks_loss", False)


# ============================================================
# 模型注册表
# ============================================================

class ModelRegistry:
    """管理所有模型（内置+自定义）及其训练状态"""

    def __init__(self, results_dir: str):
        self.results_dir = results_dir
        self.models_dir = os.path.join(results_dir, "models")
        self.custom_path = os.path.join(results_dir, "custom_models.json")
        self.active_path = os.path.join(results_dir, "active_model.json")
        os.makedirs(self.models_dir, exist_ok=True)

        self._models = {}
        self._active_model_id = "random_forest"
        self._load()

    def _load(self):
        """加载内置模型和自定义模型"""
        # 内置模型
        for mid, config in BUILTIN_MODELS.items():
            self._models[mid] = {
                "id": mid,
                "name": config["name"],
                "name_cn": config["name_cn"],
                "description": config["description"],
                "params": config["params"],
                "param_schema": config.get("param_schema", {}),
                "builtin": True,
                "available": _is_available(mid),
                "tracks_loss": _tracks_loss(mid),
                "status": "untrained",
                "metrics": None,
                "dataset_hash": None,
                "trained_at": None,
            }
            if not _is_available(mid):
                self._models[mid]["status"] = "unavailable"
                self._models[mid]["install_hint"] = UNAVAILABLE_MSG.get(mid, "")

        # 自定义模型
        if os.path.exists(self.custom_path):
            with open(self.custom_path, "r", encoding="utf-8") as f:
                customs = json.load(f)
            for cid, cmeta in customs.items():
                self._models[cid] = cmeta

        # 扫描已有模型工件，更新训练状态
        self._scan_artifacts()

        # 激活的模型
        if os.path.exists(self.active_path):
            with open(self.active_path, "r", encoding="utf-8") as f:
                self._active_model_id = json.load(f).get("model_id", "random_forest")

    def _scan_artifacts(self):
        """扫描models目录，更新已训练模型的状态和指标"""
        if not os.path.exists(self.models_dir):
            return
        for fname in os.listdir(self.models_dir):
            if not fname.endswith(".pkl"):
                continue
            model_id = fname.replace(".pkl", "")
            if model_id in self._models:
                try:
                    artifact = self.load_artifact(model_id)
                    if artifact and artifact.get("metrics"):
                        self._models[model_id]["status"] = "trained"
                        self._models[model_id]["metrics"] = artifact["metrics"]
                        self._models[model_id]["dataset_hash"] = artifact.get("dataset_hash", "")
                        self._models[model_id]["trained_at"] = artifact.get("trained_at")
                    elif artifact:
                        self._models[model_id]["status"] = "trained"
                except Exception:
                    pass

    def _save_customs(self):
        """持久化自定义模型"""
        customs = {mid: m for mid, m in self._models.items() if not m.get("builtin")}
        with open(self.custom_path, "w", encoding="utf-8") as f:
            json.dump(customs, f, ensure_ascii=False, indent=2)

    def list_all(self) -> list:
        """列出所有模型"""
        result = []
        for mid, m in self._models.items():
            entry = {
                "id": mid,
                "name": m["name"],
                "name_cn": m.get("name_cn", m["name"]),
                "description": m.get("description", ""),
                "params": m["params"],
                "builtin": m.get("builtin", False),
                "available": m.get("available", True),
                "status": m.get("status", "untrained"),
                "trained_at": m.get("trained_at"),
                "is_active": (mid == self._active_model_id),
            }
            if m.get("metrics"):
                entry["metrics_summary"] = {
                    k: m["metrics"][k] for k in ["accuracy", "f1", "roc_auc", "pr_auc"]
                    if k in m["metrics"]
                }
            if m.get("tracks_loss"):
                entry["tracks_loss"] = True
            entry["param_schema"] = m.get("param_schema", {})
            entry["install_hint"] = m.get("install_hint", "")
            result.append(entry)
        # 内置在前，自定义在后
        return sorted(result, key=lambda x: (not x["builtin"], x["id"]))

    def add_custom(self, name: str, base_model: str, custom_params: dict = None) -> dict:
        """添加自定义模型"""
        if base_model not in BUILTIN_MODELS:
            return {"ok": False, "error": f"未知的基础模型类型: {base_model}"}
        if not _is_available(base_model):
            return {"ok": False, "error": UNAVAILABLE_MSG.get(base_model, "模型不可用")}

        cid = f"custom_{base_model}_{len([m for m in self._models.values() if not m.get('builtin')]) + 1}"

        config = BUILTIN_MODELS[base_model]
        base_params = deepcopy(config["params"])
        if custom_params:
            # 验证参数
            for k, v in custom_params.items():
                if k in config.get("param_schema", {}):
                    schema = config["param_schema"][k]
                    if schema["type"] == "int":
                        try:
                            v = int(v)
                        except (ValueError, TypeError):
                            return {"ok": False, "error": f"参数 {k} 必须是整数"}
                    elif schema["type"] == "float":
                        try:
                            v = float(v)
                        except (ValueError, TypeError):
                            return {"ok": False, "error": f"参数 {k} 必须是浮点数"}
            base_params.update(custom_params)

        meta = {
            "id": cid,
            "name": name,
            "name_cn": name,
            "description": f"自定义模型 (基于 {config['name_cn']})",
            "base_model": base_model,
            "params": base_params,
            "param_schema": config.get("param_schema", {}),
            "builtin": False,
            "available": True,
            "tracks_loss": _tracks_loss(base_model),
            "status": "untrained",
            "metrics": None,
            "dataset_hash": None,
            "trained_at": None,
        }
        self._models[cid] = meta
        self._save_customs()
        return {"ok": True, "model": meta}

    def remove(self, model_id: str) -> dict:
        """删除自定义模型"""
        if model_id not in self._models:
            return {"ok": False, "error": "模型不存在"}
        if self._models[model_id].get("builtin"):
            return {"ok": False, "error": "不能删除内置模型"}

        # 删除模型文件
        artifact_path = os.path.join(self.models_dir, f"{model_id}.pkl")
        if os.path.exists(artifact_path):
            os.remove(artifact_path)

        del self._models[model_id]
        if self._active_model_id == model_id:
            self._active_model_id = "random_forest"
            self._save_active()
        self._save_customs()
        return {"ok": True}

    def get(self, model_id: str) -> dict:
        """获取模型信息"""
        return self._models.get(model_id)

    def set_active(self, model_id: str) -> dict:
        """设置活跃筛选模型"""
        if model_id not in self._models:
            return {"ok": False, "error": "模型不存在"}
        m = self._models[model_id]
        if not m.get("available"):
            return {"ok": False, "error": f"模型不可用: {m.get('install_hint', '')}"}
        self._active_model_id = model_id
        self._save_active()
        return {"ok": True, "model_id": model_id}

    def get_active(self) -> str:
        """获取当前活跃模型ID"""
        return self._active_model_id

    def get_active_model_info(self) -> dict:
        """获取活跃模型的详细信息"""
        m = self._models.get(self._active_model_id, {})
        return {
            "id": self._active_model_id,
            "name": m.get("name", ""),
            "name_cn": m.get("name_cn", ""),
            "metrics": m.get("metrics"),
            "threshold": (m.get("metrics") or {}).get("threshold", 0.5),
        }

    def save_artifact(self, model_id: str, artifact: dict, dataset_hash: str):
        """保存模型训练结果"""
        # Merge metrics from in-memory model state into artifact for persistence
        if model_id in self._models and self._models[model_id].get("metrics"):
            artifact["metrics"] = self._models[model_id]["metrics"]
        artifact["trained_at"] = datetime.now().isoformat()
        artifact["dataset_hash"] = dataset_hash

        path = os.path.join(self.models_dir, f"{model_id}.pkl")
        with open(path, "wb") as f:
            pickle.dump(artifact, f)
        self._models[model_id]["status"] = "trained"
        self._models[model_id]["dataset_hash"] = dataset_hash
        self._models[model_id]["trained_at"] = artifact["trained_at"]
        self._models[model_id]["metrics"] = artifact.get("metrics", self._models[model_id].get("metrics"))
        if not self._models[model_id].get("builtin"):
            self._save_customs()

    def load_artifact(self, model_id: str) -> dict:
        """加载模型训练结果"""
        path = os.path.join(self.models_dir, f"{model_id}.pkl")
        if os.path.exists(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        return None

    def invalidate_by_hash(self, dataset_hash: str):
        """当数据集变更时，使旧模型失效"""
        for mid, m in self._models.items():
            if m.get("status") == "trained" and m.get("dataset_hash") != dataset_hash:
                m["status"] = "stale"
                m["metrics"] = None
                m["dataset_hash"] = None
                m["trained_at"] = None
                artifact_path = os.path.join(self.models_dir, f"{mid}.pkl")
                if os.path.exists(artifact_path):
                    os.remove(artifact_path)

    def _save_active(self):
        with open(self.active_path, "w", encoding="utf-8") as f:
            json.dump({"model_id": self._active_model_id}, f)
