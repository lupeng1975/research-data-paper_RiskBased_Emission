# -*- coding: utf-8 -*-
"""
数据源适配器 —— Schema-Agnostic Data Loader
自动检测CSV格式，适配任意学术数据源
可复现学术溯源系统 · Seed 20260729
"""

import os
import json
import hashlib
from datetime import datetime

import numpy as np
import pandas as pd


# ============================================================
# 多编码兼容 CSV 读取
# ============================================================

_ENCODING_CHAIN = ["utf-8-sig", "utf-8", "gbk", "gb18030"]


def _read_csv_safe(file_path: str, **kwargs) -> pd.DataFrame:
    """按编码链尝试读取CSV，兼容UTF-8和GBK编码文件"""
    last_err = None
    for enc in _ENCODING_CHAIN:
        try:
            return pd.read_csv(file_path, encoding=enc, **kwargs)
        except UnicodeDecodeError as e:
            last_err = e
            continue
    raise last_err


# ============================================================
# 字段别名映射（不同数据集的不同命名 → 标准显示名）
# ============================================================

ALIAS_MAP = {
    "transit_duration": ["transit_duration", "transit_days", "transit_time", "duration"],
    "door_open_count": ["door_open_count", "door_opens", "door_open", "openings"],
    "temp_mean": ["temp_mean", "temp_mean_c", "mean_temp", "avg_temp", "temperature_mean"],
    "temp_max": ["temp_max", "temp_max_c", "max_temp", "temperature_max"],
    "temp_min": ["temp_min", "temp_min_c", "min_temp", "temperature_min"],
    "temp_std": ["temp_std", "temp_std_c", "std_temp", "temperature_std"],
    "temp_recovery_rate": ["temp_recovery_rate", "temp_recovery", "recovery_rate"],
    "rh_mean": ["rh_mean", "mean_rh", "avg_rh", "humidity_mean"],
    "rh_std": ["rh_std", "std_rh", "humidity_std"],
    "rh_max": ["rh_max", "rh_max_c", "max_rh", "humidity_max"],
    "rh_min": ["rh_min", "rh_min_c", "min_rh", "humidity_min"],
    "package_type": ["package_type", "packaging", "package", "pkg_type"],
    "product_volume": ["product_volume", "product_volume_l", "volume", "vol"],
    "fill_rate": ["fill_rate", "fill_ratio", "fill", "capacity"],
    "carrier_id": ["carrier_id", "carrier", "transporter", "logistics"],
    "origin_region": ["origin_region", "origin_zone", "origin", "source", "from"],
    "dest_region": ["dest_region", "dest_zone", "destination", "dest", "to"],
    "segment_count": ["segment_count", "leg_count", "segments", "legs", "stops"],
    "sensor_interval": ["sensor_interval", "sensor_gap_hours", "sensor_gap", "interval"],
    "vibration_index": ["vibration_index", "vibration", "shock", "vib"],
}


def _resolve_alias(col_name: str) -> str:
    """将任意列名映射到标准显示名，找不到则返回原名"""
    name_lower = col_name.lower().replace(" ", "_").replace("-", "_")
    for canonical, aliases in ALIAS_MAP.items():
        for alias in aliases:
            if alias.lower() == name_lower:
                return canonical
    return col_name


# ============================================================
# Schema 检测
# ============================================================

# 标签列可能的命名模式
LABEL_PATTERNS = [
    "silent_failure", "label", "target", "^y$", "class", "failure",
    "anomaly", "outcome", "is_failure", "is_anomaly", "ground_truth",
    "silent", "fail", "fault",
]

# ID列可能的命名模式
ID_PATTERNS = [
    "shipment_id", "^id$", "sample_id", "subject_id", "case_id",
    "record_id", "index", "row_id", "uuid", "identifier",
]

# 日期/时间列可能的命名模式（高基数，不适合作为分类特征）
# 注意：只用精确词匹配，避免误伤 vehicle_age_years 等
DATE_PATTERNS = [
    "test_date", "date", "time", "timestamp", "datetime",
]


def detect_schema(df: pd.DataFrame) -> dict:
    """
    自动检测CSV的数据模式
    返回: {id_col, label_col, numeric_cols, categorical_cols, excluded_cols, n_rows, n_cols}
    """
    import re

    n_rows, n_cols = df.shape
    result = {
        "id_col": None,
        "label_col": None,
        "numeric_cols": [],
        "categorical_cols": [],
        "excluded_cols": [],
        "all_cols": list(df.columns),
        "n_rows": n_rows,
        "n_cols": n_cols,
        "label_distribution": None,
    }

    # 1. 检测ID列（完全唯一 或 几乎唯一 ≥95%）
    for col in df.columns:
        col_lower = col.lower().replace(" ", "_").replace("-", "_")
        for pattern in ID_PATTERNS:
            if re.search(pattern, col_lower):
                if df[col].nunique() >= n_rows * 0.95:  # 几乎唯一即视为ID
                    result["id_col"] = col
                    break
        if result["id_col"]:
            break

    # 1b. 未匹配ID模式但存在几乎唯一的列（如 vehicle_id 8749/8759）
    if not result["id_col"]:
        for col in df.columns:
            if df[col].nunique() >= n_rows * 0.95:
                # 字符串类型且几乎唯一 → 作为ID排除
                if df[col].dtype == object or pd.api.types.is_string_dtype(df[col]):
                    result["id_col"] = col
                    break

    # 2. 检测标签列
    label_candidates = []
    for col in df.columns:
        if col == result["id_col"]:
            continue
        col_lower = col.lower().replace(" ", "_").replace("-", "_")
        for pattern in LABEL_PATTERNS:
            if re.search(pattern, col_lower):
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) == 2 and set(unique_vals).issubset({0, 1, 0.0, 1.0}):
                    label_candidates.append(col)
                break

    if label_candidates:
        result["label_col"] = label_candidates[0]
    else:
        # 回退: 找最后一个二值列
        for col in reversed(df.columns):
            if col == result["id_col"]:
                continue
            unique_vals = df[col].dropna().unique()
            if len(unique_vals) == 2 and set(unique_vals).issubset({0, 1, 0.0, 1.0}):
                result["label_col"] = col
                break

    # 3. 分类列与数值列
    excluded = {result["id_col"], result["label_col"]}
    for col in df.columns:
        if col in excluded:
            continue

        col_lower = col.lower().replace(" ", "_").replace("-", "_")
        n_unique = df[col].nunique()
        missing_rate = df[col].isna().mean()

        # 排除几乎全空或常数列
        if missing_rate > 0.9 or n_unique <= 1:
            result["excluded_cols"].append(col)
            continue

        # 排除日期/时间列（高基数，不适合作为分类特征）
        is_date_col = any(re.search(p, col_lower) for p in DATE_PATTERNS)
        if is_date_col and n_unique > 50:
            result["excluded_cols"].append(col)
            print(f"[detect_schema] 日期列 '{col}' 已自动排除 "
                  f"(基数={n_unique}/{n_rows})")
            continue

        # 排除高基数字符串列（>100个唯一值 或 >50%行数）
        is_string = (df[col].dtype == object or pd.api.types.is_string_dtype(df[col]))
        if is_string and n_unique > max(100, n_rows * 0.2):
            result["excluded_cols"].append(col)
            print(f"[detect_schema] 高基数列 '{col}' 已自动排除 "
                  f"(基数={n_unique}/{n_rows})")
            continue

        # 分类特征: object/string类型 或 低基数数值(≤15类，且≤10%行数)
        if is_string:
            result["categorical_cols"].append(col)
        elif n_unique <= min(15, max(2, n_rows * 0.05)):
            result["categorical_cols"].append(col)
        else:
            result["numeric_cols"].append(col)

    # 3b. 检测衍生目标列（target_*, label_* 前缀），排除以防止标签泄露
    extra_excluded = []
    for col in list(result["numeric_cols"] + result["categorical_cols"]):
        col_lower_check = col.lower().replace(" ", "_").replace("-", "_")
        if col_lower_check.startswith("target_") or col_lower_check.startswith("label_"):
            extra_excluded.append(col)
            if col in result["numeric_cols"]:
                result["numeric_cols"].remove(col)
            if col in result["categorical_cols"]:
                result["categorical_cols"].remove(col)
            if col not in result["excluded_cols"]:
                result["excluded_cols"].append(col)
    if extra_excluded:
        print(f"[detect_schema] 衍生目标列已自动排除（避免标签泄露）: {extra_excluded}")

    # 3c. 泄漏检测：检查数值特征中是否存在与标签列高度相似的列名
    leakage_detected = []
    if result["label_col"]:
        label_clean = result["label_col"].lower().replace("_", "").replace("-", "").replace(" ", "")
        # 从标签名中提取基础参数名（去除 target_ / label_ 前缀）
        base_name = label_clean
        for prefix in ["target", "label", "class", "is_"]:
            if base_name.startswith(prefix):
                base_name = base_name[len(prefix):]
                break

        for col in list(result["numeric_cols"]):
            col_clean = col.lower().replace("_", "").replace("-", "").replace(" ", "")
            # 特征列名等于标签的基础参数名（如 label=target_TP, feature=TP）
            if col_clean == base_name:
                leakage_detected.append((col, f"特征列 '{col}' 与标签列 '{result['label_col']}' 存在直接衍生关系（{col} 的阈值判定即为标签），已排除"))
                result["numeric_cols"].remove(col)
                if col not in result["excluded_cols"]:
                    result["excluded_cols"].append(col)

    if leakage_detected:
        result["leakage_warnings"] = [
            {"column": col, "reason": reason}
            for col, reason in leakage_detected
        ]
        print(f"[detect_schema] WARNING: {len(leakage_detected)} label leakage feature(s) detected and auto-excluded:")
        for w in result["leakage_warnings"]:
            print(f"  - {w['column']}: {w['reason']}")

    # 4. 标签分布
    if result["label_col"]:
        vc = df[result["label_col"]].value_counts()
        result["label_distribution"] = {str(k): int(v) for k, v in vc.items()}
        pos_count = int(vc.get(1, 0))
        result["positive_rate"] = round(pos_count / n_rows, 4) if n_rows > 0 else 0
        nan_count = int(df[result["label_col"]].isna().sum())
        if nan_count > 0:
            result["warning"] = (
                f"标签列 '{result['label_col']}' 包含 {nan_count} 个缺失值 "
                f"({nan_count / n_rows * 100:.1f}%)，将在训练时自动移除"
            )

    # 5. 缺失值统计
    missing = {}
    for col in df.columns:
        n_missing = int(df[col].isna().sum())
        if n_missing > 0:
            missing[col] = n_missing
    result["missing_values"] = missing

    return result


def validate_schema(df: pd.DataFrame, mapping: dict) -> tuple[bool, str]:
    """
    验证用户确认的映射是否有效
    mapping: {label_col, id_col?, exclude_cols?}
    """
    label_col = mapping.get("label_col")
    if not label_col or label_col not in df.columns:
        return False, f"标签列 '{label_col}' 不在数据集中"

    unique_vals = df[label_col].dropna().unique()
    if len(unique_vals) != 2:
        return False, f"标签列必须为二值，当前有 {len(unique_vals)} 个不同值"
    if not set(unique_vals).issubset({0, 1, 0.0, 1.0, True, False}):
        return False, f"标签列值必须为0/1，当前值: {unique_vals}"

    feature_cols = [c for c in df.columns
                    if c != label_col
                    and c != mapping.get("id_col")
                    and c not in mapping.get("exclude_cols", [])]
    if len(feature_cols) < 2:
        return False, f"特征列至少需要2列，当前仅 {len(feature_cols)} 列"

    return True, "OK"


# ============================================================
# 数据集管理器
# ============================================================

class DatasetManager:
    """管理多个数据源：注册、激活、加载、哈希校验"""

    def __init__(self, data_dir: str, results_dir: str):
        self.data_dir = data_dir
        self.results_dir = results_dir
        self.uploads_dir = os.path.join(data_dir, "uploads")
        self.active_path = os.path.join(data_dir, "active_dataset.json")
        self.registry_path = os.path.join(data_dir, "dataset_registry.json")
        os.makedirs(self.uploads_dir, exist_ok=True)

        self._active_meta = None
        self._active_df = None
        self._load_active()

    def _file_hash(self, file_path: str) -> str:
        """文件的SHA-256哈希"""
        if not os.path.exists(file_path):
            return ""
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def register(self, file_path: str, name: str = None) -> dict:
        """
        注册一个数据集文件
        返回: {dataset_id, name, path, hash, schema: {...}}
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"数据集文件不存在: {file_path}")

        df = _read_csv_safe(file_path)
        schema = detect_schema(df)
        file_hash = self._file_hash(file_path)

        dataset_id = hashlib.md5(file_path.encode()).hexdigest()[:12]
        meta = {
            "dataset_id": dataset_id,
            "name": name or os.path.basename(file_path),
            "path": file_path,
            "hash": file_hash,
            "schema": schema,
            "registered_at": datetime.now().isoformat(),
        }

        # 持久化到注册表
        registry = self._load_registry()
        registry[dataset_id] = meta
        with open(self.registry_path, "w", encoding="utf-8") as f:
            json.dump(registry, f, ensure_ascii=False, indent=2)

        return meta

    def activate(self, dataset_id: str, mapping: dict = None) -> dict:
        """
        激活指定数据集
        mapping可覆盖自动检测的{label_col, id_col, exclude_cols}
        """
        registry = self._load_registry()
        if dataset_id not in registry:
            return {"ok": False, "error": f"数据集 {dataset_id} 未注册"}

        meta = registry[dataset_id].copy()
        df = _read_csv_safe(meta["path"])

        # 始终重新检测schema（包括泄露检测），确保使用最新的检测逻辑
        new_schema = detect_schema(df)

        if mapping:
            valid, msg = validate_schema(df, mapping)
            if not valid:
                return {"ok": False, "error": msg}
            new_schema["label_col"] = mapping["label_col"]
            new_schema["id_col"] = mapping.get("id_col")
            if "exclude_cols" in mapping:
                # 用户指定的排除列追加到自动检测的排除列之后
                for col in mapping["exclude_cols"]:
                    if col not in new_schema["excluded_cols"]:
                        new_schema["excluded_cols"].append(col)
                    if col in new_schema["numeric_cols"]:
                        new_schema["numeric_cols"].remove(col)
                    if col in new_schema["categorical_cols"]:
                        new_schema["categorical_cols"].remove(col)

        meta["schema"] = new_schema

        # 重新计算positive_rate
        label_col = meta["schema"]["label_col"]
        if label_col:
            vc = df[label_col].value_counts()
            meta["schema"]["label_distribution"] = {str(k): int(v) for k, v in vc.items()}
            meta["schema"]["positive_rate"] = round(
                int(vc.get(1, 0)) / len(df), 4) if len(df) > 0 else 0

        # 保存激活信息
        active_meta = {
            "dataset_id": dataset_id,
            "name": meta["name"],
            "path": meta["path"],
            "hash": meta["hash"],
            "schema": meta["schema"],
            "activated_at": datetime.now().isoformat(),
        }
        with open(self.active_path, "w", encoding="utf-8") as f:
            json.dump(active_meta, f, ensure_ascii=False, indent=2)

        self._active_meta = active_meta
        self._active_df = df
        return {"ok": True, "meta": active_meta}

    def load_active(self) -> pd.DataFrame:
        """加载当前激活的数据集（自动检测文件变化并刷新schema）"""
        if not self._active_meta:
            raise RuntimeError("没有激活的数据集")

        file_path = self._active_meta["path"]
        # 始终重新读取CSV，防止缓存过期
        df = _read_csv_safe(file_path)
        self._active_df = df

        # 自动检测数据行数变化，更新schema
        actual_rows = len(df)
        cached_rows = self._active_meta["schema"].get("n_rows", 0)
        if actual_rows != cached_rows:
            new_schema = detect_schema(df)
            # 保留用户设定的label_col/id_col
            new_schema["label_col"] = self._active_meta["schema"]["label_col"]
            new_schema["id_col"] = self._active_meta["schema"].get("id_col")
            if "excluded_cols" in self._active_meta["schema"]:
                new_schema["excluded_cols"] = self._active_meta["schema"]["excluded_cols"]
            self._active_meta["schema"] = new_schema
            # 持久化更新后的schema
            with open(self.active_path, "w", encoding="utf-8") as f:
                json.dump(self._active_meta, f, ensure_ascii=False, indent=2)
            print(f"[DatasetManager] 检测到数据行数变化: {cached_rows} → {actual_rows}，"
                  f"schema已自动刷新")

        return df

    def refresh(self):
        """手动刷新：清除缓存，重新读取数据和schema"""
        self._active_df = None
        if self._active_meta:
            file_path = self._active_meta["path"]
            df = _read_csv_safe(file_path)
            schema = detect_schema(df)
            # 保留用户映射
            schema["label_col"] = self._active_meta["schema"]["label_col"]
            schema["id_col"] = self._active_meta["schema"].get("id_col")
            if "excluded_cols" in self._active_meta["schema"]:
                schema["excluded_cols"] = self._active_meta["schema"]["excluded_cols"]
            self._active_meta["schema"] = schema
            self._active_df = df
            with open(self.active_path, "w", encoding="utf-8") as f:
                json.dump(self._active_meta, f, ensure_ascii=False, indent=2)
            print(f"[DatasetManager] 已刷新: {len(df)} 行, {schema.get('n_cols', '?')} 列")
            return self._active_meta
        return None

    def get_active_meta(self) -> dict:
        """获取当前激活数据集的元数据"""
        if self._active_meta:
            return self._active_meta
        return {}

    def list_all(self) -> dict:
        """列出所有已注册的数据集"""
        registry = self._load_registry()
        active_id = self._active_meta["dataset_id"] if self._active_meta else None
        result = []
        for did, meta in registry.items():
            result.append({
                "dataset_id": did,
                "name": meta["name"],
                "hash": meta["hash"][:16] + "...",
                "n_rows": meta["schema"]["n_rows"],
                "n_cols": meta["schema"]["n_cols"],
                "label_col": meta["schema"]["label_col"],
                "positive_rate": meta["schema"].get("positive_rate", "N/A"),
                "registered_at": meta["registered_at"],
                "is_active": (did == active_id),
            })
        return {"ok": True, "datasets": sorted(result, key=lambda x: x["registered_at"], reverse=True)}

    def _load_registry(self) -> dict:
        if os.path.exists(self.registry_path):
            with open(self.registry_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def _load_active(self):
        """启动时加载已激活的数据集"""
        if os.path.exists(self.active_path):
            with open(self.active_path, "r", encoding="utf-8") as f:
                self._active_meta = json.load(f)
            # 不预加载df，按需加载


# ============================================================
# 预处理器构建（从schema自动生成）
# ============================================================

from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer


def build_preprocessor(schema: dict) -> ColumnTransformer:
    """
    根据schema自动构建预处理流水线
    schema应包含: numeric_cols, categorical_cols
    """
    numeric_cols = schema.get("numeric_cols", [])
    categorical_cols = schema.get("categorical_cols", [])

    transformers = []

    if numeric_cols:
        num_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ])
        transformers.append(("num", num_pipe, numeric_cols))

    if categorical_cols:
        cat_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ])
        transformers.append(("cat", cat_pipe, categorical_cols))

    if not transformers:
        raise ValueError("没有可用于预处理的特征列")

    return ColumnTransformer(transformers)


def get_feature_columns(schema: dict) -> list:
    """返回所有特征列（数值+分类）"""
    return schema.get("numeric_cols", []) + schema.get("categorical_cols", [])


def get_display_name(col: str) -> str:
    """将列名映射到友好的显示名"""
    return _resolve_alias(col)
