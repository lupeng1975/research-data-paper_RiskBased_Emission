# -*- coding: utf-8 -*-
"""
时序验证模型 —— sklearn兼容的PyTorch LSTM分类器
滑动窗口序列建模, 捕捉传感器数据的时间依赖关系
可复现学术溯源系统 · Seed 20260729
"""

import numpy as np
import pandas as pd

from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.utils.validation import check_is_fitted

SEED_INT = 20260729

# 可选依赖（与 XGB/LGB 模式一致）
TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    TORCH_AVAILABLE = True
except ImportError:
    torch = nn = DataLoader = TensorDataset = None


# ============================================================
# 序列构建（模块级, 向量化）
# ============================================================

def _make_sequences(X: np.ndarray, seq_len: int) -> np.ndarray:
    """
    滑动窗口构建时序序列。
    对每个样本 i, 取 [i - seq_len + 1, ..., i] 作为上下文窗口。
    开头不足 seq_len 的样本用零填充前缀。

    参数
    ----
    X : ndarray (n_samples, n_features)
    seq_len : int  窗口长度

    返回
    ----
    sequences : ndarray (n_samples, seq_len, n_features)
        输出行数与输入严格一致
    """
    X = np.asarray(X, dtype=np.float32)
    n, d = X.shape
    if n == 0:
        return np.zeros((0, seq_len, d), dtype=np.float32)
    seq_len = min(seq_len, n)
    # 前置零填充
    pad = np.zeros((seq_len - 1, d), dtype=np.float32)
    Xp = np.vstack([pad, X])                          # (n + seq_len - 1, d)
    # 向量化索引: 每行 i 取 Xp[i : i+seq_len]
    idx = np.arange(seq_len)[None, :] + np.arange(n)[:, None]  # (n, seq_len)
    return Xp[idx]                                    # (n, seq_len, d)


# ============================================================
# PyTorch LSTM 内部模块
# ============================================================

class _LSTMModule(nn.Module):
    """LSTM 二分类器: LSTM → FC → sigmoid logit"""

    def __init__(self, n_features, hidden_dim=64, num_layers=2, dropout=0.2):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.fc = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x):
        """x: (batch, seq_len, n_features) → (batch,) logits"""
        out, _ = self.lstm(x)           # out: (B, S, H)
        last = out[:, -1, :]            # 取最后时间步: (B, H)
        return self.fc(last).squeeze(-1)  # (B,)


# ============================================================
# sklearn 兼容包装器
# ============================================================

class LSTMClassifier(BaseEstimator, ClassifierMixin):
    """
    PyTorch LSTM 二分类器, sklearn 兼容。

    参数
    ----
    seq_len : int, 默认 12
        滑动窗口长度 —— 每个样本使用前 seq_len 行作为时序上下文
    hidden_dim : int, 默认 64
        LSTM 隐层维度
    num_layers : int, 默认 2
        LSTM 层数 (≥2 时启用层间 dropout)
    dropout : float, 默认 0.2
        Dropout 比例
    lr : float, 默认 0.001
        Adam 学习率
    epochs : int, 默认 100
        最大训练轮数
    batch_size : int, 默认 256
        批次大小
    patience : int, 默认 10
        早停耐心值
    validation_fraction : float, 默认 0.15
        内部验证集比例
    random_state : int, 默认 20260729
        随机种子
    """

    def __init__(self, seq_len=12, hidden_dim=64, num_layers=2,
                 dropout=0.2, lr=0.001, epochs=100, batch_size=256,
                 patience=10, validation_fraction=0.15,
                 random_state=SEED_INT):
        self.seq_len = seq_len
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.dropout = dropout
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.patience = patience
        self.validation_fraction = validation_fraction
        self.random_state = random_state

    # ── sklearn 参数接口 ──

    def get_params(self, deep=True):
        return {
            "seq_len": self.seq_len,
            "hidden_dim": self.hidden_dim,
            "num_layers": self.num_layers,
            "dropout": self.dropout,
            "lr": self.lr,
            "epochs": self.epochs,
            "batch_size": self.batch_size,
            "patience": self.patience,
            "validation_fraction": self.validation_fraction,
            "random_state": self.random_state,
        }

    def set_params(self, **params):
        for k, v in params.items():
            if hasattr(self, k):
                setattr(self, k, v)
        return self

    # ── Pickle 健壮性: 保存 state_dict 而非完整 nn.Module ──

    def __getstate__(self):
        state = self.__dict__.copy()
        if "model_" in state and state["model_"] is not None:
            state["model_"] = {
                "state_dict": {k: v.cpu().numpy() for k, v in state["model_"].state_dict().items()},
                "n_features_in_": getattr(self, "n_features_in_", None),
            }
        return state

    def __setstate__(self, state):
        md = state.pop("model_", None)
        self.__dict__.update(state)
        if isinstance(md, dict) and md.get("n_features_in_") is not None:
            m = _LSTMModule(md["n_features_in_"], self.hidden_dim,
                            self.num_layers, self.dropout)
            m.load_state_dict({k: torch.from_numpy(v) for k, v in md["state_dict"].items()})
            m.eval()
            self.model_ = m
        else:
            self.model_ = None

    # ── 训练 ──

    def fit(self, X, y):
        """
        训练 LSTM 模型。

        参数
        ----
        X : array-like (n_samples, n_features)
            特征矩阵（已通过预处理器）
        y : array-like (n_samples,)
            二分类标签 {0, 1}

        返回
        ----
        self
        """
        if not TORCH_AVAILABLE:
            raise ImportError(
                "PyTorch 未安装，无法训练 LSTM 模型。\n"
                "请运行: pip install torch"
            )

        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.int64).ravel()

        n_samples, n_features = X.shape
        if n_features == 0:
            raise ValueError("输入特征数为 0")
        if len(np.unique(y)) < 2:
            raise ValueError("训练集需要至少 2 个类别")

        self.n_features_in_ = n_features
        self.classes_ = np.array([0, 1])

        # 内部分层验证集划分
        rng = np.random.RandomState(self.random_state)
        n_val = max(2, int(n_samples * self.validation_fraction))
        val_mask = np.zeros(n_samples, dtype=bool)
        for c in np.unique(y):
            ci = np.where(y == c)[0]
            rng.shuffle(ci)
            n_val_c = max(1, int(len(ci) * self.validation_fraction))
            val_mask[ci[:n_val_c]] = True
        tr_mask = ~val_mask

        # 回退: 验证集缺少某个类时随机划分
        if len(np.unique(y[tr_mask])) < 2 or len(np.unique(y[val_mask])) < 2:
            perm = rng.permutation(n_samples)
            tr_mask = np.zeros(n_samples, dtype=bool)
            tr_mask[perm[:n_samples - n_val]] = True
            val_mask = perm[n_samples - n_val:]

        # 构建序列
        seqs_tr = _make_sequences(X[tr_mask], self.seq_len)
        seqs_va = _make_sequences(X[val_mask], self.seq_len)
        y_tr, y_va = y[tr_mask], y[val_mask]

        # 固定种子
        torch.manual_seed(self.random_state)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(self.random_state)

        # 构建模型
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = _LSTMModule(n_features, self.hidden_dim,
                            self.num_layers, self.dropout).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=self.lr)
        criterion = nn.BCEWithLogitsLoss()

        loader = DataLoader(
            TensorDataset(torch.from_numpy(seqs_tr), torch.from_numpy(y_tr).float()),
            batch_size=self.batch_size, shuffle=True,
            generator=torch.Generator().manual_seed(self.random_state),
        )

        # 训练循环 + 早停
        best_state = None
        best_val = float("inf")
        loss_curve = []
        patience_cnt = 0

        for epoch in range(self.epochs):
            # ── 训练 ──
            model.train()
            ep_losses = []
            for xb, yb in loader:
                xb, yb = xb.to(device), yb.to(device)
                optimizer.zero_grad()
                loss = criterion(model(xb), yb)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                ep_losses.append(float(loss.detach()))
            loss_curve.append(float(np.mean(ep_losses)))

            # ── 验证 ──
            model.eval()
            with torch.no_grad():
                vlogits = model(torch.from_numpy(seqs_va).to(device))
                vloss = float(criterion(vlogits, torch.from_numpy(y_va).float().to(device)))

            if vloss < best_val - 1e-4:
                best_val = vloss
                patience_cnt = 0
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            else:
                patience_cnt += 1
                if patience_cnt >= self.patience:
                    break

        # 恢复最佳模型并冻结
        if best_state is not None:
            model.load_state_dict(best_state)
        model.eval()
        self.model_ = model
        self._device_ = device

        # 输出 loss_curve_（与 MLP 格式一致，仅训练损失）
        self.loss_curve_ = np.asarray(loss_curve, dtype=float)
        self.best_val_loss_ = float(best_val)
        self.n_epochs_ = len(loss_curve)

        return self

    # ── 预测 ──

    def _forward_logits(self, X):
        """分批前向传播，返回 (n,) logits"""
        seqs = _make_sequences(X, self.seq_len)
        model = self.model_
        device = self._device_
        model.eval()

        all_logits = []
        bs = self.batch_size * 2
        with torch.no_grad():
            for i in range(0, len(seqs), bs):
                xb = torch.from_numpy(seqs[i:i + bs]).float().to(device)
                all_logits.append(model(xb).cpu().numpy())
        return np.concatenate(all_logits)

    def predict_proba(self, X):
        """
        预测类别概率。

        返回
        ----
        proba : ndarray (n_samples, 2)
            [P(y=0), P(y=1)]
        """
        check_is_fitted(self, "model_")
        if self.model_ is None:
            raise RuntimeError("模型未正确加载（state_dict 为空）")

        if isinstance(X, pd.DataFrame):
            X = X.values
        X = np.asarray(X, dtype=np.float32)
        if X.ndim == 1:
            X = X.reshape(1, -1)

        if X.shape[1] != self.n_features_in_:
            raise ValueError(
                f"输入特征数 {X.shape[1]} 与训练时的 {self.n_features_in_} 不匹配"
            )

        logits = self._forward_logits(X)
        p1 = 1.0 / (1.0 + np.exp(-logits))          # sigmoid
        return np.column_stack([1.0 - p1, p1])      # (n, 2)

    def predict(self, X):
        """预测类别标签 {0, 1}"""
        proba = self.predict_proba(X)
        return (proba[:, 1] >= 0.5).astype(int)
