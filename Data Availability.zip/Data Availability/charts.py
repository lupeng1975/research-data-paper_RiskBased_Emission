# -*- coding: utf-8 -*-
"""
学术图表生成器 —— SCI 论文级可交互图表
图例加大+贴近图表 · 混淆矩阵annotation重绘 · 梯度下降加大间距
"""

import os, json, numpy as np
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots
from sklearn.metrics import (roc_curve, precision_recall_curve, log_loss)

pio.templates.default = "plotly_white"

# ── 全局常量 ──
FIG_WIDTH  = 960
FIG_HEIGHT = 520
SQUARE     = 540
TITLE_SIZE = 14
AXIS_SIZE  = 12
TICK_SIZE  = 10
LGND_SIZE  = 10                    # 图例字号加大
LINE_W     = 2.2
BASE_W     = 1.0
FONT       = "Noto Sans SC, Arial, sans-serif"
MARGIN     = {"l": 60, "r": 25, "t": 55, "b": 55}
MARGIN_SQ  = {"l": 90, "r": 25, "t": 75, "b": 55}

COLORS = {"frost":"#0088a8","frost_dim":"#6bafc0","ice":"#1a6b8a",
          "safe":"#00b894","warn":"#e07830","danger":"#d63031",
          "chain":"#c7920a","accent":"#00886b"}
MC = ["#0088a8","#00b894","#e07830","#d63031","#6c5ce7",
      "#0984e3","#c7920a","#e84393","#00cec9","#636e72"]

def _j(fig): return fig.to_json(pretty=False)

def _title(text, sub=""):
    s = f"<b>{text}</b>"
    if sub:
        s += f"<br><span style='font-size:{TICK_SIZE}px;color:#7b8a9b'>{sub}</span>"
    return {"text":s,"font":{"family":FONT,"size":TITLE_SIZE},"x":0.02,"xanchor":"left"}

def _xa(label=""):
    d = {"tickfont":{"family":FONT,"size":TICK_SIZE},"showgrid":True,
         "gridcolor":"#e8ecf0","zeroline":False,"showline":True,
         "linewidth":1,"linecolor":"#d0d8e0"}
    if label: d["title"] = {"text":label,"font":{"family":FONT,"size":AXIS_SIZE}}
    return d

def _ya(label="", rang=None):
    d = {"tickfont":{"family":FONT,"size":TICK_SIZE},"showgrid":True,
         "gridcolor":"#e8ecf0","zeroline":False,"showline":True,
         "linewidth":1,"linecolor":"#d0d8e0"}
    if label: d["title"] = {"text":label,"font":{"family":FONT,"size":AXIS_SIZE}}
    if rang is not None: d["range"] = rang
    return d

def _leg(y=-0.12):
    """图例：贴近图表底部，字号 10pt"""
    return {"font":{"family":FONT,"size":LGND_SIZE},"orientation":"h",
            "yanchor":"top","y":y,"xanchor":"center","x":0.5,
            "bgcolor":"rgba(255,255,255,0.5)","itemsizing":"constant"}

def _shorten(name: str) -> str:
    m = {"random_forest":"RF","extra_trees":"ET","gradient_boosting":"GBDT",
         "logistic_regression":"LR","mlp":"MLP","svm":"SVM",
         "xgboost":"XGB","lightgbm":"LGBM","lstm":"LSTM",
         "Random Forest":"RF","Extra Trees":"ET","Gradient Boosting":"GBDT",
         "Logistic Regression":"LR","Mlp":"MLP","Svm":"SVM",
         "Xgboost":"XGB","Lightgbm":"LGBM","Lstm":"LSTM"}
    return m.get(name, name[:6])


# ═══════════════════════════════════════════════════
# 1. 模型指标对比
# ═══════════════════════════════════════════════════
def chart_metric_comparison(report: dict) -> str:
    results = report.get("results",{})
    models = []
    data = {k:[] for k in ["Accuracy","Precision","Recall","F1","ROC-AUC","PR-AUC"]}
    for mid,res in results.items():
        if res.get("status") in ("error","unavailable"): continue
        models.append(_shorten(mid))
        data["Accuracy"].append(res.get("accuracy",0))
        data["Precision"].append(res.get("precision",0))
        data["Recall"].append(res.get("recall",0))
        data["F1"].append(res.get("f1",0))
        data["ROC-AUC"].append(res.get("roc_auc",0))
        data["PR-AUC"].append(res.get("pr_auc",0))
    if not models: return "<p>无可比模型数据</p>"

    fig = go.Figure()
    x = np.arange(len(models)); w = 0.12
    for i,(metric,vals) in enumerate(data.items()):
        fig.add_trace(go.Bar(name=metric, x=x+i*w-0.36, y=vals, width=w,
                             marker_color=MC[i%len(MC)],
                             text=[f"{v:.3f}" for v in vals],
                             textposition="none",
                             hovertemplate=f"{metric}: %{{y:.4f}}<extra></extra>"))
    fig.update_layout(
        title=_title("Model Performance Comparison", f"{len(models)} models × 6 metrics"),
        xaxis={"tickvals":x.tolist(),"ticktext":models,
               "tickfont":{"family":FONT,"size":9},"tickangle":-25},
        yaxis=_ya("Score",[0,1.06]), barmode="group", legend=_leg(-0.22),
        width=FIG_WIDTH, height=FIG_HEIGHT, margin={"l":60,"r":25,"t":55,"b":80},
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 2. ROC 曲线
# ═══════════════════════════════════════════════════
def chart_roc_curves(report: dict) -> str:
    results = report.get("results",{})
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0,1],y=[0,1],mode="lines",
                   line={"dash":"dash","color":"gray","width":BASE_W},
                   name="Chance (AUC=0.5)"))
    for i,(mid,res) in enumerate(results.items()):
        if res.get("status") in ("error","unavailable"): continue
        yt=res.get("_y_true"); yp=res.get("_y_prob")
        if not yt or not yp: continue
        yt=np.array(yt); yp=np.array(yp)
        fpr,tpr,_=roc_curve(yt,yp)
        auc=res.get("roc_auc",0)
        fig.add_trace(go.Scatter(x=fpr,y=tpr,mode="lines",
            name=f"{_shorten(mid)} AUC={auc:.3f}",
            line={"width":LINE_W,"color":MC[i%len(MC)]},
            hovertemplate=f"AUC={auc:.4f}<extra></extra>"))
    fig.update_layout(
        title=_title("ROC Curves"),
        xaxis=_xa("False Positive Rate"), yaxis=_ya("True Positive Rate",[0,1.02]),
        legend=_leg(-0.22), width=FIG_WIDTH, height=FIG_HEIGHT, margin=MARGIN,
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 3. PR 曲线
# ═══════════════════════════════════════════════════
def chart_pr_curves(report: dict) -> str:
    results = report.get("results",{})
    fig = go.Figure()
    pos=0.2
    for res in results.values():
        if res.get("_y_true"): pos=np.array(res["_y_true"]).mean(); break
    fig.add_trace(go.Scatter(x=[0,1],y=[pos,pos],mode="lines",
                   line={"dash":"dash","color":"gray","width":BASE_W},
                   name=f"No-skill π={pos:.3f}"))
    for i,(mid,res) in enumerate(results.items()):
        if res.get("status") in ("error","unavailable"): continue
        yt=res.get("_y_true"); yp=res.get("_y_prob")
        if not yt or not yp: continue
        yt=np.array(yt); yp=np.array(yp)
        prec,rec,_=precision_recall_curve(yt,yp)
        ap=res.get("pr_auc",0)
        fig.add_trace(go.Scatter(x=rec,y=prec,mode="lines",
            name=f"{_shorten(mid)} AP={ap:.3f}",
            line={"width":LINE_W,"color":MC[i%len(MC)]}))
    fig.update_layout(
        title=_title("Precision-Recall Curves"),
        xaxis=_xa("Recall"), yaxis=_ya("Precision",[0,1.02]),
        legend=_leg(-0.22), width=FIG_WIDTH, height=FIG_HEIGHT, margin=MARGIN,
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 4. 混淆矩阵 — 用 annotation 重绘，彻底解决文字重叠
# ═══════════════════════════════════════════════════
def chart_cm_heatmap(model_results: dict, model_name: str = "") -> str:
    cm = model_results.get("confusion_matrix",{})
    if not cm: return "<p>无混淆矩阵数据</p>"
    tn=cm.get("tn",0); fp=cm.get("fp",0); fn=cm.get("fn",0); tp=cm.get("tp",0)
    total=tn+fp+fn+tp
    if total==0: return "<p>混淆矩阵数据无效</p>"

    acc=(tp+tn)/total
    prec=tp/(tp+fp) if (tp+fp)>0 else 0
    rec =tp/(tp+fn) if (tp+fn)>0 else 0

    # 每格颜色
    fill = [
        ["rgba(0,184,148,0.55)","rgba(224,120,48,0.45)"],
        ["rgba(214,48,49,0.40)","rgba(100,145,190,0.30)"],
    ]
    labels = [["TP","FP"],["FN","TN"]]
    values = [[tp,fp],[fn,tn]]
    pcts   = [[tp/total*100,fp/total*100],[fn/total*100,tn/total*100]]

    # 用 Heatmap 做底
    fig = go.Figure()
    fig.add_trace(go.Heatmap(
        z=[[1,3],[2,4]],
        x=["Predicted Positive","Predicted Negative"],
        y=["Actual Positive","Actual Negative"],
        colorscale=[[0,"white"],[1,"white"]], showscale=False,
        hoverinfo="skip", zmin=0, zmax=5,
    ))

    # 矩形背景色
    for i in range(2):
        for j in range(2):
            fig.add_shape(type="rect", x0=j-0.48,x1=j+0.48,
                          y0=i-0.48,y1=i+0.48,
                          fillcolor=fill[i][j],
                          line={"color":"white","width":3}, layer="below")

    # 逐格添加 annotation，精确控制位置和字体
    for i in range(2):
        for j in range(2):
            # 大字：计数
            fig.add_annotation(
                x=j, y=i-0.18, text=f"<b>{values[i][j]}</b>",
                showarrow=False, font={"family":FONT,"size":42,"color":"#0f1a2a"},
                xref="x", yref="y")
            # 中字：标签
            fig.add_annotation(
                x=j, y=i+0.08, text=f"{labels[i][j]}",
                showarrow=False, font={"family":FONT,"size":14,"color":"#0f1a2a"},
                xref="x", yref="y")
            # 小字：百分比
            fig.add_annotation(
                x=j, y=i+0.25, text=f"({pcts[i][j]:.1f}%)",
                showarrow=False, font={"family":FONT,"size":11,"color":"#556677"},
                xref="x", yref="y")

    fig.update_layout(
        title=_title("Confusion Matrix",
                     f"N={total}  |  Acc={acc:.4f}  |  Prec={prec:.4f}  |  Rec={rec:.4f}"),
        xaxis={"tickfont":{"family":FONT,"size":12},"side":"top",
               "scaleanchor":"y","scaleratio":1,"constrain":"domain"},
        yaxis={"tickfont":{"family":FONT,"size":12},"autorange":"reversed",
               "scaleanchor":"x","scaleratio":1,"constrain":"domain"},
        width=SQUARE, height=SQUARE, margin=MARGIN_SQ, plot_bgcolor="white",
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 5. 预测标签分布
# ═══════════════════════════════════════════════════
def chart_predicted_label_dist(report: dict) -> str:
    results = report.get("results",{})
    models,p0,p1,t1=[],[],[],[]
    for mid,res in results.items():
        if res.get("status") in ("error","unavailable"): continue
        dist=res.get("predicted_label_distribution",{})
        yt=res.get("_y_true")
        models.append(_shorten(mid))
        p0.append(dist.get(0,0)); p1.append(dist.get(1,0))
        t1.append(int(sum(yt)) if yt else 0)
    if not models: return "<p>无预测分布数据</p>"

    fig = go.Figure()
    x=np.arange(len(models))
    fig.add_trace(go.Bar(name="Predicted 0",x=x,y=p0,marker_color=COLORS["frost_dim"]))
    fig.add_trace(go.Bar(name="Predicted 1",x=x,y=p1,marker_color=COLORS["warn"]))
    fig.add_trace(go.Scatter(name="Actual Pos",x=x,y=t1,mode="markers+lines",
                   marker={"color":COLORS["danger"],"size":9,"symbol":"diamond"},
                   line={"width":LINE_W,"dash":"dot"}))
    fig.update_layout(
        title=_title("Predicted Label Distribution"),
        xaxis={"tickvals":x.tolist(),"ticktext":models,
               "tickfont":{"family":FONT,"size":TICK_SIZE},"tickangle":-25},
        yaxis=_ya("Count"), barmode="stack", legend=_leg(-0.22),
        width=FIG_WIDTH, height=FIG_HEIGHT, margin={"l":60,"r":25,"t":55,"b":80},
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 6. 梯度下降损失曲线 — 加高加大间距
# ═══════════════════════════════════════════════════
def chart_gradient_descent_loss(X, y) -> str:
    if X is None or y is None: return "<p>需要数据集以计算梯度下降曲线</p>"
    if hasattr(X,'values'): X=X.values
    if hasattr(y,'values'): y=y.values
    X=np.array(X,dtype=float); y=np.array(y,dtype=float).ravel()
    valid=~np.isnan(X).any(axis=1); X=X[valid]; y=y[valid]
    if len(y)<100: return "<p>有效样本量不足</p>"
    from sklearn.preprocessing import StandardScaler
    from sklearn.impute import SimpleImputer
    X=SimpleImputer(strategy="median").fit_transform(X)
    X=StandardScaler().fit_transform(X)
    X=np.hstack([X,np.ones((X.shape[0],1))])
    ns,nf=X.shape; epochs=400; lrs=[0.5,0.1,0.01]

    # 更大的子图间距和整体高度
    fig=make_subplots(rows=1,cols=2,
        subplot_titles=("<b>MSE Loss</b>","<b>Cross-Entropy Loss</b>"),
        horizontal_spacing=0.18)

    for lr in lrs:
        # MSE
        w=np.random.RandomState(42).randn(nf)*0.01; mse=[]
        for ep in range(epochs):
            idx=np.random.RandomState(ep).randint(0,ns,min(256,ns))
            Xb,yb=X[idx],y[idx]
            p=1/(1+np.exp(-Xb.dot(w))); w-=lr*Xb.T.dot(p-yb)/len(yb)
            fp=1/(1+np.exp(-X.dot(w))); mse.append(np.mean((fp-y)**2))
        fig.add_trace(go.Scatter(x=list(range(epochs)),y=mse,mode="lines",
            name=f"η={lr}",line={"width":LINE_W}),row=1,col=1)
        # CE
        w=np.random.RandomState(42).randn(nf)*0.01; ce=[]
        for ep in range(epochs):
            idx=np.random.RandomState(ep).randint(0,ns,min(256,ns))
            Xb,yb=X[idx],y[idx]
            p=np.clip(1/(1+np.exp(-Xb.dot(w))),1e-15,1-1e-15); w-=lr*Xb.T.dot(p-yb)/len(yb)
            fp=np.clip(1/(1+np.exp(-X.dot(w))),1e-15,1-1e-15)
            ce.append(-np.mean(y*np.log(fp)+(1-y)*np.log(1-fp)))
        fig.add_trace(go.Scatter(x=list(range(epochs)),y=ce,mode="lines",
            name=f"η={lr}",line={"width":LINE_W},showlegend=False),row=1,col=2)

    fa={"family":FONT,"size":AXIS_SIZE}; ft={"family":FONT,"size":TICK_SIZE}
    for c in [1,2]:
        fig.update_xaxes(title_text="Epoch",title_font=fa,tickfont=ft,row=1,col=c)
    fig.update_yaxes(title_text="MSE Loss",title_font=fa,tickfont=ft,row=1,col=1)
    fig.update_yaxes(title_text="Cross-Entropy Loss",title_font=fa,tickfont=ft,row=1,col=2)
    fig.update_layout(
        title=_title("Gradient Descent Loss Curves","SGD batch=256; η=0.5 / 0.1 / 0.01"),
        legend=_leg(-0.12),
        width=FIG_WIDTH, height=FIG_HEIGHT+40,  # 加高
        margin={"l":60,"r":25,"t":55,"b":60},
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 7. 交叉熵损失对比
# ═══════════════════════════════════════════════════
def chart_cross_entropy_loss(report: dict) -> str:
    results = report.get("results",{})
    models,losses=[],[]
    for mid,res in results.items():
        if res.get("status") in ("error","unavailable"): continue
        yt=res.get("_y_true"); yp=res.get("_y_prob")
        if yt and yp:
            losses.append(round(log_loss(yt,yp),4))
        elif "log_loss" in res:
            losses.append(round(res["log_loss"],4))
        else:
            continue
        models.append(_shorten(mid))
    if not models: return "<p>无损失数据</p>"
    best=min(losses)
    clrs=[COLORS["safe"] if l==best else COLORS["frost"] for l in losses]
    fig=go.Figure(data=go.Bar(x=models,y=losses,marker_color=clrs,
                text=[f"{l:.4f}" for l in losses],textposition="none",
                hovertemplate="Log Loss: %{y:.4f}<extra></extra>"))
    fig.update_layout(
        title=_title("Cross-Entropy Loss (Log Loss)",f"Best = {best:.4f}"),
        xaxis={"tickfont":{"family":FONT,"size":TICK_SIZE},"tickangle":-25},
        yaxis=_ya("Log Loss"),
        width=FIG_WIDTH, height=FIG_HEIGHT, margin={"l":60,"r":25,"t":55,"b":65},
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 8. KL散度 + 校准分析
# ═══════════════════════════════════════════════════
def chart_kl_divergence(report: dict) -> str:
    results = report.get("results",{})
    fig=make_subplots(rows=1,cols=2,
        subplot_titles=("<b>Reliability Diagram</b>","<b>KL Divergence</b>"),
        horizontal_spacing=0.18)
    klv={}
    for i,(mid,res) in enumerate(results.items()):
        if res.get("status") in ("error","unavailable"): continue
        yt=res.get("_y_true"); yp=res.get("_y_prob")
        if not yt or not yp: continue
        yt=np.array(yt); yp=np.array(yp)
        bins=np.linspace(0,1,11); bc,be=[],[]
        for j in range(len(bins)-1):
            mask=(yp>=bins[j])&(yp<bins[j+1])
            if mask.sum()>=5: bc.append((bins[j]+bins[j+1])/2); be.append(yt[mask].mean())
        if bc:
            fig.add_trace(go.Scatter(x=bc,y=be,mode="lines+markers",
                name=_shorten(mid), line={"width":LINE_W,"color":MC[i%len(MC)]},
                marker={"size":5}), row=1,col=1)
        ph,_=np.histogram(yp,bins=20,range=(0,1),density=True)
        th,_=np.histogram(yt,bins=20,range=(0,1),density=True)
        ph=np.clip(ph,1e-10,None); th=np.clip(th,1e-10,None)
        ph/=ph.sum(); th/=th.sum()
        klv[mid]=float(np.sum(th*np.log(th/ph)))

    fig.add_trace(go.Scatter(x=[0,1],y=[0,1],mode="lines",
        line={"dash":"dash","color":"gray","width":BASE_W},
        name="Perfect",showlegend=False),row=1,col=1)

    if klv:
        km=[_shorten(m) for m in klv]; kv=list(klv.values()); best_kl=min(kv)
        fig.add_trace(go.Bar(x=km,y=kv,
            marker_color=[COLORS["safe"] if v==best_kl else COLORS["frost"] for v in kv],
            text=[f"{v:.4f}" for v in kv], textposition="none",
            hovertemplate="KL: %{y:.4f}<extra></extra>"), row=1,col=2)

    fa={"family":FONT,"size":AXIS_SIZE}; ft={"family":FONT,"size":TICK_SIZE}
    fig.update_xaxes(title_text="Predicted Probability",title_font=fa,tickfont=ft,row=1,col=1)
    fig.update_yaxes(title_text="Empirical Rate",title_font=fa,tickfont=ft,row=1,col=1)
    fig.update_xaxes(title_text="Model",title_font=fa,tickfont=ft,tickangle=-25,row=1,col=2)
    fig.update_yaxes(title_text="KL Divergence",title_font=fa,tickfont=ft,row=1,col=2)
    fig.update_layout(
        title=_title("KL Divergence & Calibration"),
        legend=_leg(-0.12), width=FIG_WIDTH, height=FIG_HEIGHT, margin={"l":60,"r":25,"t":55,"b":65},
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 9. 特征重要性
# ═══════════════════════════════════════════════════
def chart_feature_importance(feature_names: list, importance_values: list,
                              model_name: str = "Random Forest") -> str:
    if not feature_names or not importance_values: return "<p>无特征重要性数据</p>"
    idx=np.argsort(importance_values)[-15:]
    names=[feature_names[i] for i in idx]
    values=[importance_values[i] for i in idx]
    med=np.median(values)
    clrs=[COLORS["frost"] if v>=med else COLORS["frost_dim"] for v in values]
    fig=go.Figure(data=go.Bar(y=names,x=values,orientation="h",marker_color=clrs,
                text=[f"{v:.4f}" for v in values],textposition="outside",
                textfont={"size":10,"family":FONT}))
    fig.update_layout(
        title=_title(f"Feature Importance — {model_name}","Top 15"),
        xaxis=_xa("Importance Score"),
        yaxis={"tickfont":{"family":FONT,"size":TICK_SIZE},"autorange":"reversed"},
        width=FIG_WIDTH, height=FIG_HEIGHT, margin={"l":130,"r":60,"t":55,"b":50},
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 10. 阈值分析
# ═══════════════════════════════════════════════════
def chart_threshold_analysis(report: dict) -> str:
    results=report.get("results",{})
    first=None
    for mid,res in results.items():
        if res.get("status") not in ("error","unavailable") and res.get("_y_prob"):
            first=res; break
    if not first: return "<p>无有效模型数据</p>"
    yt=np.array(first["_y_true"]); yp=np.array(first["_y_prob"])
    th=np.linspace(0.05,0.95,91)
    prec,rec,f1=[],[],[]
    from sklearn.metrics import precision_score,recall_score,f1_score
    for t in th:
        ypr=(yp>=t).astype(int)
        prec.append(precision_score(yt,ypr,zero_division=0))
        rec.append(recall_score(yt,ypr,zero_division=0))
        f1.append(f1_score(yt,ypr,zero_division=0))
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=th,y=prec,mode="lines",name="Precision",
                   line={"width":LINE_W,"color":COLORS["frost"]}))
    fig.add_trace(go.Scatter(x=th,y=rec,mode="lines",name="Recall",
                   line={"width":LINE_W,"color":COLORS["warn"]}))
    fig.add_trace(go.Scatter(x=th,y=f1,mode="lines",name="F1",
                   line={"width":LINE_W+1,"color":COLORS["safe"]}))
    bi=np.argmax(f1)
    fig.add_trace(go.Scatter(x=[th[bi]],y=[f1[bi]],mode="markers",
                   marker={"color":COLORS["safe"],"size":14,"symbol":"star"},
                   name=f"Max F1={f1[bi]:.3f}"))
    fig.update_layout(
        title=_title("Threshold Analysis"),
        xaxis=_xa("Decision Threshold τ"), yaxis=_ya("Score",[0,1.05]),
        legend=_leg(-0.12), width=FIG_WIDTH, height=FIG_HEIGHT, margin=MARGIN,
    )
    return _j(fig)


# ═══════════════════════════════════════════════════
# 批量 & 缓存
# ═══════════════════════════════════════════════════

def generate_all_charts(report: dict, X=None, y=None) -> dict:
    charts = {}
    if report and report.get("results"):
        charts["metric_bar"] = chart_metric_comparison(report)
        charts["roc_curves"] = chart_roc_curves(report)
        charts["pr_curves"] = chart_pr_curves(report)
        charts["label_dist"] = chart_predicted_label_dist(report)
        charts["ce_loss"] = chart_cross_entropy_loss(report)
        charts["kl_div"] = chart_kl_divergence(report)
        charts["threshold"] = chart_threshold_analysis(report)
        for mid, res in report["results"].items():
            if res.get("status") not in ("error","unavailable"):
                charts["cm_heatmap"] = chart_cm_heatmap(res, mid); break
    if X is not None and y is not None:
        charts["gradient_descent"] = chart_gradient_descent_loss(X, y)
    return charts


def cache_charts(charts: dict, results_dir: str):
    d = os.path.join(results_dir, "charts"); os.makedirs(d, exist_ok=True)
    for old in os.listdir(d):
        if old.endswith(".html") or old.endswith(".json"):
            os.remove(os.path.join(d, old))
    for cid, js in charts.items():
        with open(os.path.join(d, f"{cid}.json"), "w", encoding="utf-8") as f:
            f.write(js)


def load_cached_charts(results_dir: str) -> dict:
    d = os.path.join(results_dir, "charts"); charts = {}
    if os.path.exists(d):
        for fn in os.listdir(d):
            if fn.endswith(".json"):
                with open(os.path.join(d, fn), "r", encoding="utf-8") as f:
                    charts[fn.replace(".json", "")] = f.read()
    return charts
